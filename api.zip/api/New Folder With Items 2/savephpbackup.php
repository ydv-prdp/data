<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$base64 = $_POST['data'];
$finalResult = $_POST['result'];
$userId = $_POST['user_id'];
$contentP = $_POST['content_p'];
//$product_id = 100;
//$userId = 1;
// echo "<script>console.log('kkkk" .$contentP. "') </script>"; 

//echo "<script>console.log('userId = " . $_POST['user_id']. "') </script>";


require_once 'src/config/config.php';
require_once 'src/config/connect.php';
require_once 'src/utils/GeneralMethod.php';
require_once 'src/utils/ConnectionManager.php';
require_once __DIR__ . '/vendor/autoload.php';



$genMethod      = new GeneralMethod();
$db             = new ConnectionManager();

$upload_dir = '/var/www/html/UXMM/images';
//$upload_dir = 'C:/xampp/htdocs/UXMM/UXMM/images';

$filename = save_image_file($base64,$upload_dir);

$filename=$filename."";

//print_r('http://localhost/UXMM/'.$filename);
//sleep(5);

$sQuery = "SELECT user_id,email,fname,lname FROM users WHERE is_deleted = 0 AND user_id = :user_id";
$db->query($sQuery);
$db->bind(":user_id", $userId);
$rowEmail = $db->single();

if(! empty($rowEmail['email'])) {
    $email = $rowEmail['email'];
//        $rowEmail['email']="varshasbharadwaj@gmail.com";
//                var_dump($email);
//                exit();
//        $crypt_email = $genMethod->simple_crypt($email, 'e');
    
    $mpdf = new \Mpdf\Mpdf(['tempDir' => __DIR__ . '/pdf','format' => 'A4-L'],'siemens-sans');
    $mpdf->SetFont('siemens-sans');
    $mpdf->debug =true;
    
    $mpdf->showImageErrors =true;
    


   
    $src ='http://132.186.158.154/UXMM/images/'.$filename.'.png';
    //$src ='http://localhost:81/UXMM/images/'.$filename.'.png';
      echo "<script>console.log('Debug Objects: " .$src. "') </script>";

    $mpdf->WriteHTML("<!DOCTYPE html>
<html>
<head>
    <title>Product Report</title>
                <style type='text/css'>
                    @page  {
                    margin: 5%;
                    
                    }
                    body{font-family: 'siemens-sans';}
                    .report{height:683px;width: 1030px;background-color: #009999;}
                   .logo1{position: absolute; right: 0; margin-right: 3%;margin-top: 3%}.down{position: absolute;bottom: 5px;right: 0;}.text-content{position: relative;text-align: right;color: #f7f7f7;padding: 5px} .main-text{font-size: 36px;font-weight: 900;} p{font-size: 18px;	font-weight: 900;}
                    .result-headding{color: #00ADAF;font-size: 26px;font-weight: 900;}.tagline{color: #000000;font-size: 12px;font-weight: 900;padding-left: 10px;font-style:italic}.col-lg-6{width: 525px;margin: 10px;}.rep-content{background-color: #00ADAF}
                    .box{width: 450px; height: 400px;color: #ffffff;margin: 3px;background-color: #009999;border:2px solid #009999; vertical-align: top;}
                    .right{
                        position: absolute;right: 0;}
                       
                    </style>
            </head>
<body>
<div class = 'report' style='height:100%;width: 100%;background-color: #009999;margin-top: 2%;'>
<img class='logo1' style='float: right; margin-right: 3%;margin-top: 3%' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
<div class='down' style='margin-top: 90vh;right: 0;'>
                  <div class='text-content' style='margin-right: 3%'> 
                        <p class='main-text' style='margin: 0;margin-top: 500px;padding: 0;font-size: 36px;font-weight: bold;	letter-spacing: 1px;' >UX MEASUREMENT REPORT FOR </p>
                        <p class='main-text' style='padding: 0;margin: 0;font-size: 36px;font-weight: bold;'>".$finalResult['product_name']." ".$finalResult['version']."  </p>
                        <p style='font-size: 18px;font-weight: 900;padding: 0;'> Prepared by CT RDA SSI UXD-IN for ".$rowEmail['fname']." ".$rowEmail['lname']."</p>
                  </div>
        </div>
</div>
<div>
    <div>
        <img style='float: right' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
        <span class='result-headding'>".$finalResult['product_name']." ".$finalResult['version']." - UX measurement results</span><br>
       <span class='tagline'>The experience calculated is an in-depth evaluation of the product based on five <br>main parameters or components that define the overall experience.</span>
        
    </div>
    <div style='float: left;width:48%;margin-top:60px'>                       
        <img src=".$src." >
        <p style='font-style:italic;font-size:14px;text-align:center'>Above diagram showcases the scores across parameters </p>

    </div>
    <div style='float: right;width:450px;height:400px;background-color:#009999;color: #ffffff;padding:20px;'>
        <div style='float: left;width:22%;margin-left: 15px;'>
            <h1 style='font-size: 38px;font-weight: bold;margin-top:10px;text-align:left'>" . $finalResult['percentail'] . "</h1>
        </div>
        <div style='float: right;width:70%; margin-bottom:0'>  
            <p style='padding:0;margin:0;margin-top:10px'> UX Score for ".$finalResult['product_name']." ".$finalResult['version']." </p>
            <p style='padding:0;margin:0'> based on UXMM evaluation </p>
        </div>
        <div style='width:100%'> <hr style='height: 2px;color: #ffffff;margin-top:0'>
        </div>
        <ul>
            <li>
            <p style='font-size: 18px;font-style:italic'>" . $finalResult['positive'] . "</p></li>
            <li> <p style='font-size: 18px;font-style:italic'>" . $finalResult['negative'] . "</p></li>
        </ul>
    </div>
</div>    
    
<div style='height:100%;width: 100%;'>
    <img src='img/Report/A4Copy.png'>
</div>  
<div style='height:100%;width: 100%;'>
    <img src='img/Report/A4Copy8.png'>
</div> 
<div class = 'report' style='height:100%;width: 100%;background-color: #009999;margin-top: 2%;'>
<div class='down' style='margin-top: 90vh;right: 0;'>
                  <div class='text-content' style='margin-right: 3%'> 
                        <p class='main-text' style='margin: 0;margin-top: 580px;padding: 0;font-size: 36px;font-weight: bold;	letter-spacing: 1px;' >Thank You </p>
                        
                  </div>
        </div>
</div> 

                



</body>
</html>");
    $time = date('ymdhis');

   $mpdf->Output('/var/www/html/UXMM/pdf/' . $time . '.pdf','F');
   //$mpdf->Output('/UXMM/pdf/' . $time . '.pdf','F');
   
//   $mpdf->Output('/var/www/html/pdf/' . $time . '.pdf','F');
//    $pdfLink = 'http://172.16.152.36/pdf/'.$time.'.pdf';
    $message="<html xmlns='https://www.w3.org/1999/xhtml' xmlns:v='urn:schemas-microsoft-com:vml'
    xmlns:o='urn:schemas-microsoft-com:office:office'>

<head>
    <!--[if gte mso 9]><xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
    </xml><![endif]-->
    <title>UXMM Email</title>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0 '>
    <meta name='format-detection' content='telephone=no'>
    <!--[if !mso]><!-->
    <link href='https://db.onlinewebfonts.com/c/0e6de1ec911a2e267ff136bbdd384a44?family=Helvetica+Neue' rel='stylesheet'
        type='text/css' />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet'>
    <!--<![endif]-->
    <style type='text/css'>
    <style type='text/css'>
    body {
  margin: 0 !important;
  padding: 0 !important;
  -webkit-text-size-adjust: 100% !important;
  -ms-text-size-adjust: 100% !important;
  -webkit-font-smoothing: antialiased !important;
}
  </style>
    </style>
</head>
<body width='680' style='width:680px;margin:auto;'>
    <div class='body-wrapper' style='width: 680px;background-color: #fff;'>
        <table align='center' width='680px' border='0' cellspacing='0' class='em_main_table' style='width:680px;'>
            <div style='height:11px; background-color: #FEB103;Width:680px'></div>
            <tbody>
                <tr>
                    <td valign='top' align='center'>
                        <table class='em_main_table' style='width:558px;'  width='558'
                            cellspacing='0' cellpadding='0' border='0'>
                            <!--Header section-->
                            <tbody>
                                <td class='em_h20' style='font-size:0px; line-height:0px; height:34px;' height='34'>
                                    &nbsp;</td>
                                <tr>
                                    <td class='em_padd' valign='top'>
                                        <table style='width:558px;padding-bottom: 10px;border-bottom:1px solid #FEB103;'
                                            width='100%' cellspacing='0' cellpadding='0' align='center'>
                                            <tbody>
                                                <tr>
                                                    <td style='color: #707070;width:121px;font-family: helvetica neue;font-weight:bold; font-size:46px; line-height:55px;text-align:
                                                        -webkit-left' align='center'>
                                                        UXMM </td>
                                                    <td style='color: #BDBDBD;font-size:18px;padding-left: 5px;line-height:18px;font-family: helvetica neue;font-weight:bold;'>User Experience
                                                        Measurement</br> & Management Model</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <!--//Header section-->

                                <!--Content Text Section-->
                                <tr>
                                    <td style='font-size:0px; line-height:0px; height:35px;' height='30'>&nbsp;</td>
                                    <!--—this is space of 15px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <!-- <td style='font-size:0px; line-height:0px; height:35px;' height='30'>&nbsp;</td> -->
                                    <td style='width:558px' class='em_padd' width='558' valign='top' align='center'>
                                        <table width='558px;' cellspacing='0' cellpadding='0' border='0' align='center'>
                                            <tbody>
                                                <tr>
                                                    <td style='font-family:Arial, sans-serif; font-size:16px; line-height:24px;text-align:-webkit-left;color: #4F5A68;'
                                                        valign='top' align='left'>
                                                        Hello ".$rowEmail['fname']."
                                                        </td>
                                                </tr>
                                                <td style='font-size:0px; line-height:0px; height:35px;' height='30'>
                                                    &nbsp;</td>
                                                <!--—this is space of 15px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family: Arial, sans-serif; font-size:18px; line-height:24px; color:#4F5A68; letter-spacing:0; padding-bottom:12px; width:558px;'
                                        valign='top' align='left'>
                                        Thank you for taking out time and measuring
                                        ".$finalResult['product_name']." experience.
                                        By having a sneak peek into the world of experience of your product
                                        ".$finalResult['product_name'].",
                                        UXMM was able to provide some very useful insights.</br>
                                        Please download the attachment for a detailed result.
                                    </td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:18px; line-height:24px; color:#4F5A68; letter-spacing:0; width:558px;'
                                        valign='top' align='left'>
                                        The Experience Score of ".$finalResult['product_name']." is
                                        ".$finalResult['percentail']."
                                    </td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:18px; line-height:24px; color:#4F5A68; letter-spacing:0;'
                                        valign='top' align='left'>
                                        PS. To
                                        dig deeper into UX of your product you may want to
                                        conduct an expert evaluation through 77 comprehensive
                                        attributes of the main model. Please feel free to contact us
                                        for further details</td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:40px;' height='40'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:16px; line-height:24px; color:#4F5A68; letter-spacing:0;'
                                        valign='top' align='center'>
                                        Want to explore further?</td>
                                </tr>
                </tr>
                <tr>
                    <td class='em_h20' style='font-size:0px; line-height:0px; height:12px;' height='12'>&nbsp;</td>
                    <!--—this is space of 25px to separate two paragraphs ---->
                </tr>
               
                
                <table style='width:257px;color:#FFFFFF;'
                width='257' cellspacing='0' cellpadding='0' align='center'>
                <tbody>
                    <tr>
                        <td style='font-family: helvetica neue;font-weight:bold; font-size:15px;text-decoration: none;line-height:18px; color:#FFFFFF; letter-spacing:0;'
                        valign='middle' align='center' height='50' width='257' bgcolor='#FEB103'>
                       <a href='http://132.186.158.154/UXMM/thank-page.html' target='_blank' color='#FFFFFF' style='cursor: pointer;text-decoration:none;color:#FFFFFF !important;'>GET IN TOUCH WITH XD LAB</a>
                    </td>
                    </tr>
                </tbody>
            </table>
                <tr>
                    <td class='em_h20' style='font-size:0px; line-height:0px; height:50px;' height='50'>&nbsp;</td>
                    <!--—this is space of 25px to separate two paragraphs ---->
                </tr>
                <tr>
                    <td style='font-family:Arial, sans-serif; font-size:24px; line-height:24px; letter-spacing:0;text-decoration:none;'
                        valign='top' align='center'>
                        <a href='https://www.yammer.com/siemens.com/#/threads/inGroup?type=in_group&feedId=352231424&view=all' target='_blank' style='cursor: pointer;text-decoration:none;'><img src='https://upload.wikimedia.org/wikipedia/commons/1/1f/Yammer_logo.png' style='display:block;' height='35' width='35' class=''></a>
                    </td>
                </tr>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>

        <!--//Content Text Section-->
        <!--Footer Section-->
        <tr>
            <td style='font-family:Arial, sans-serif; font-size:11px; line-height:18px; color:#999999;' valign='top'
                align='center' height='15'>
            </td>
        </tr>
        <tr>
            <td style='font-family: Arial, sans-serif; font-size:11px; line-height:18px; color:#999999;' valign='top'
                align='center'>
                
            </td>
        </tr>
        <tr>
            <td style='font-family: helvetica neue;font-weight: bold; font-size:11px; opacity: .8;line-height:18px; color:#707070;' valign='top'
                align='center'>
                © 2020 Siemens 
            </td>
        </tr>
        <tr>
            <td style='font-family: helvetica neue;font-size:8px; line-height:10px; color:#707070;opacity: .8;width:550pxtext-decoration:none;' valign='top'
                align='center'>
                This automatically generated report is created by UXMM. To know more get in touch with XD Lab | CT RDA SSI UXD-IN or write to <a color='#707070' style='text-decoration:none;color:#707070!important'>XDlab@siemens.com</a> 
            </td>
        </tr>
        <tr>
        <td style='font-family: helvetica neue;font-size:8px; line-height:10px; color:#707070;opacity: .8;width:550px' valign='top'
            align='center'>
            This report is designed to be print-friendly. For internal consumption only. 
        </td>
    </tr>
        <tr>
            <td class='em_h20' style='font-size:0px; line-height:0px; height:50px;' height='50'>&nbsp;</td>
            <!--—this is space of 25px to separate two paragraphs ---->
        </tr>
        </tbody>
        </table>
        </td>
        </tr>
        <tr>
            <td class='em_h20' style='font-size:0px; line-height:0px; height:50px;' height='50'>&nbsp;</td>
            <!--—this is space of 25px to separate two paragraphs ---->
        </tr>
        </tbody>
        </table>
        </td>
        </tr>
        </tbody>
        </table>
    </div>
</body>

</html>";
//    $mpdf->Output('/var/www/madhu_inst/public_html/siemens/pdf/MyPDF-test2.pdf', 'F');

//    file_put_contents('/var/www/madhu_inst/public_html/siemens/pdf/' . $time . '.pdf', $output);

    $genMethod->sendMails($rowEmail['email'], 'Siemens-UXMM Product Report ', $message, $time);
    $aList[JSON_TAG_STATUS] = 0;


}

function save_image_file( $base64, $upload_dir ){
    
    $needle = strpos( $base64, ',' );

    if ( $needle !== false ) {
        $base64  = substr( $base64, $needle + 1 );
        $base64    = base64_decode( $base64 );
        $uid     = uniqid();
        $file    = $uid;
        $success = file_put_contents( $upload_dir . '/' . $file.'.png', $base64 );
        
        return $success ? $uid : false;
    }
    
//    return false;
}

?>
