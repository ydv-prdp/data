<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$base64 = $_POST['data'];
$finalResult = $_POST['result'];
$userId = $_POST['user_id'];
$contentP = $_POST['content_p'];
$product_id = $_POST['product_id'];
//$product_id = 100;
//$userId = 1;
// echo "<script>console.log('kkkk" .$contentP. "') </script>"; 
//echo "<script>console.log('userId = " . $_POST['user_id']. "') </script>";


require_once 'src/config/config.php';
require_once 'src/config/connect.php';
require_once 'src/utils/GeneralMethod.php';
require_once 'src/utils/ConnectionManager.php';
require_once __DIR__ . '/vendor/autoload.php';



$genMethod      = new GeneralMethod();
$db             = new ConnectionManager();

//$upload_dir = '/var/www/html/DMI/images';
$upload_dir = '/var/www/html/DMI/api/img/Report';

$filename = save_image_file($base64,$upload_dir);

$filename=$filename."";

//print_r('http://localhost/UXMM/'.$filename);
//sleep(5);
echo "<script>console.log('before') </script>";
$sQuery = "SELECT user_id,email,fname,lname FROM users WHERE is_deleted = 0 AND user_id = :user_id";
$db->query($sQuery);
$db->bind(":user_id", $userId);
$rowEmail = $db->single();
//$rowEmail['email']="rani.joseph@siemens.com";

if(! empty($rowEmail['email'])) {
    $email = $rowEmail['email'];
    echo "<script>console.log('after db') </script>";
    $mpdf = new \Mpdf\Mpdf(['tempDir' => __DIR__ . '/pdf','format' => 'A4-P'],'siemens-sans');
    $mpdf = new \Mpdf\Mpdf(['orientation' => 'P']);
    $mpdf->SetFont('siemens-sans');
    $mpdf->debug =true;
    $mpdf->showImageErrors =true;
   
    $time1 = $_POST['testDate'];
    echo  $time1 ;
   

  //$src ='/DMI/images/'.$filename.'.png';
   $src ='/var/www/html/DMI/api/img/Report/'.$filename.'.png';
   echo "<script>console.log('Debug Objects: " .$src. "') </script>";

    $mpdf->WriteHTML("<!DOCTYPE html>
    <html>
    <head>
        <title>Digital Initiative Report</title>
        <link href='https://db.onlinewebfonts.com/c/0e6de1ec911a2e267ff136bbdd384a44?family=Helvetica+Neue' rel='stylesheet'
                type='text/css' />            
        <style type='text/css'>
                        @page  {
                        margin: 0;
                        }
                        body{font-family: 'siemens-sans';}
                       // .right{position: absolute;right: 30px;}
                        .bottom{position: absolute;bottom: 0px;}
                        .bottom-img{position: absolute;bottom: 0px;} 
                        .back-image{background-image: url(img/Report/report_logo.png);background-repeat: no-repeat;background-size: cover;}
                        .footer-styles{margin:0;opacity: 0.3;color: #707070;font-family: Helvetica Neue;font-size: 7px;letter-spacing: 0;line-height: 10px;text-align: center;}
                        </style>
                </head>
                <body style='width:595px;'>
               <div>
                <div class ='report-landing' style='height:842px;width:100%;background-color: #FFFFFF;'>
                  <div class='back-image' style='height:51.5%;width:100%;'>
                    <div class='report-header' style='padding-top:15px;width:85%;margin-left:auto;margin-right:auto;'>
                     <div style='float:left;width:100px;'>
                     <img src='img/Report/report-logo.jpg' style='width:0px;height:0vh;display:none;' />
                     </div> 
                     <p class='right' style='float:right;text-align:right;color:#FFFFFF;opacity:0.6;font-family:Helvetica Neue;font-size:8px;letter-spacing:0;line-height:10px;margin:0;'>Self-Test taken on ".$time1." by ".$rowEmail['fname']."</p>
                  </div>
              
                </div> 
                  <div style='width:85%;margin-left:auto;margin-right:auto;'>
                 
                  <p style='float:right;text-align:right;margin: 0;width:30%;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Overall Score</p>
                      <hr style='float:left;text-align:left;color:#84CCC0;height:1px;width:70%;margin-top:-15px;'> 
                  </div>
                 
                  <div style='margin-top:30px;width:85%;margin-left:auto;margin-right:auto;'>
                    <div style='width:60%;float:left;'>
                     <img  src=".$src." height='335' width='350' />
                    </div> 
                   <div style='float:right;width:40%;padding-top:15px;'>
                    <span style='font-size: 30px;font-weight: bold;letter-spacing: 0;line-height: 37px;color: #84CCC0;font-family:Helvetica Neue;'>" . $finalResult['percentail'] . "<span style='font-size:12px;'>%</span></span>
                    <!-- <span style='font-size: 12px;font-weight:bold;letter-spacing:0;color: #9B9B9B;line-height: 15px;margin-left: 5px;font-family:Helvetica Neue;'>" .$contentP[0]['landing']['label'] . "</span>
                    <img src='img/Report/" .$contentP[0]['landing']['smiley'] . ".svg'  height='22' width='22' style='margin-left: 5px;margin-top:10px;'> -->
                    <p style='display:block;clear:both;margin: 0;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 12px;'>This <span style='border-bottom: 1px solid #84CCC0;'>experience score</span> means:</p>
                    <p style='padding-top:20px;margin:0; color: #000000;font-size: 10px; letter-spacing: 0;line-height: 14px;font-family:Helvetica Neue;'>" .$contentP[0]['landing']['comment']. "</p> 
                    <p style='padding-top:20px;margin:0; color: #000000;font-size: 10px; letter-spacing: 0;line-height: 14px;font-family:Helvetica Neue;'>" .$contentP[0]['landing']['nxt']. "</p>
                    <p style='padding-top:10px;margin:0;color: #000000;font-size: 10px; letter-spacing: 0;line-height: 14px;'>To know more, please refer to the detailed parameter-wise analysis below.</p>
                   </div>
                </div>
                  <div style='width:85%;text-align: center;margin-left:auto;margin-right:auto;margin-top:65px;'>
                   <hr style='color:#FEB103;height:1px;width:100%;margin-top:-5px;color:#707070;opacity:0.4;'>
                   <p class='footer-styles'>This print-friendly automatically generated report is created by DMI for internal consumption only.© 2020 Siemens</p>
                  </div>
                </div>
            </div>  
            <!-- landing 1--->
              <div>   
                  <div class = 'report-landing2' style='height:842px;width:85%;margin-left:auto;margin-right:auto;background-color: #FFFFFF;margin-top:1%;padding:30px 0 0 0px;'>
                    <div class='report-header' style='display: block;'>
                    <div style='float:left;width:100px;'><img src='img/Report/report-logo.jpg'  width='80' height='32'/></div> 
                    <p class='right' style='float:right;text-align:right;color: #4A4A4A;font-family:Helvetica Neue;font-size: 8px;letter-spacing: 0;line-height: 10px;margin:0;'>Self-Test taken on ".$time1." by ".$rowEmail['fname']."</p>
                    </div>
                      
                    <!-- para div1 --->
                    <div class='functional' >
                    <div style='margin-top:45px;'>
                      <span style='float:left;text-align:left;margin: 0;width:170px;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Competence</span>
                      <hr style='margin-left:20px;float:right;text-align:right;color:#84CCC0;height:1px;width:400px;margin-top:-15px;'> 
                    </div>
                        <div style='margin-top:45px;clear:both;'>
                            <div style='width:50%;float:left'>
                              <img  src=".$src." height='285' width='300' />
                            </div> 
                            <div style='width:50%';float:right;>
                                <span style='font-size: 26px;font-family: Helvetica Neue;letter-spacing: 0;line-height: 32px;text-align: right;color: #84CCC0;font-weight: bold;'>" . $finalResult['category'][1] . "<span style='font-size:12px;'>%</span></span>
                                <!-- <span style='font-size: 12px;font-family: Helvetica Neue;font-weight: bold;letter-spacing:0;line-height: 15px;margin-left: 5px;color: #9B9B9B;'>" .$contentP[1]['functional']['label'] . "</span>
                                <img src='img/Report/" .$contentP[1]['functional']['smiley'] . ".svg'  height='22' width='22' style='margin-left: 5px;margin-top:10px;display:inline-block;margin-bottom:0;'> -->
                                <p style=' line-height: 10px;margin: 0;font-size: 10px; height: 18px;color: #4A4A4A;font-family: Helvetica Neue Bold;font-weight: 500;
                                letter-spacing: 0;'><span style='border-bottom:1px solid #84CCC0;'>Competence Score</span> for ".$finalResult['product_name']." based on your response</p>
                                <div style='width:100%;padding-top:3px;'>
                                <span style='float:left;text-align:left;margin: 0;width:52px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 10px;'>What does the score mean? </span>
                                <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:185px;margin-top:-5px;'> 
                                </div>
                                <p style='color: #4A4A4A;font-family: Helvetica Neue;font-size:9px;font-weight: 500; letter-spacing: 0;line-height: 12px;margin:0;height:45px;margin-top:-5px;'>" .$contentP[1]['functional']['comment']." </p>
                                <div style='padding-top: 10px;'>
                                <div style='width:100%;'>
                                   <span style='float:left;text-align:left;margin: 0;width:110px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 10px;'>What's next? </span>
                                   <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:240px;margin-top:-5px;'> 
                               </div>
                                    <div style='height: 96px;width: 192px;border: 1px solid #B1B1B4;border-radius: 7px;'>
                                        <p style='opacity: 0.9;color: #4A4A4A; font-family: Helvetica Neue;font-size: 9px;letter-spacing: 0;line-height: 12px;padding: 5px;margin: 0;'>" .$contentP[1]['functional']['nxt']. "</p>
                                    </div>
                                </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div style='margin-top:90px;'>
                           <span style='float:left;text-align:left;margin: 0;width:100px;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Autonomy</span>
                           <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:400px;margin-top:-15px;'> 
                        </div>
                        <div style='margin-top:45px;clear:both;'>
                            <div style='width:50%;float:left'>
                            <img  src=".$src." height='285' width='300' />
                            </div> 
                            <div style='width:50%';float:right;>
                                <span style='font-size: 26px;font-family: Helvetica Neue;letter-spacing: 0;line-height: 32px;text-align: right;color: #84CCC0;font-weight: bold;'>" . $finalResult['category'][2] . "<span style='font-size:12px;'>%</span></span>
                                <!-- <span style='font-size: 12px;font-family: Helvetica Neue;font-weight: bold;letter-spacing:0;line-height: 15px;margin-left: 5px;color: #9B9B9B;'>" .$contentP[2]['usable']['label'] . "</span>
                                <img src='img/Report/" .$contentP[2]['usable']['smiley'] . ".svg'  height='22' width='22' style='margin-left: 5px;margin-top:10px;display:inline-block;margin-bottom:0;'> -->
                                <p style=' line-height: 10px;margin: 0;font-size: 10px; height: 18px;color: #4A4A4A;font-family: Helvetica Neue Bold;font-weight: 500;
                                letter-spacing: 0;'><span style='border-bottom:1px solid #84CCC0;'>Autonomy Score</span> for ".$finalResult['product_name']." based on your response</p>
                                <div style='width:100%;padding-top:3px;'>
                                 <span style='float:left;text-align:left;margin: 0;width:110px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 10px;'>What does the score mean? </span>
                                 <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:185px;margin-top:-5px;'> 
                                </div>
                                <p style='color: #4A4A4A;font-family: Helvetica Neue;font-size:9px;font-weight: 500; letter-spacing: 0;line-height: 12px;margin: 0; height: 45px;margin-top:-5px;'>" .$contentP[2]['usable']['comment']." </p>
                                <div style='padding-top: 10px;'>
                                <div style='width:100%;padding-top:3px;'>
                                    <span style='float:left;text-align:left;margin: 0;width:110px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 10px;'>What's next? </span>
                                    <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:240px;margin-top:-5px;'> 
                                 </div>
                                    <div style='height: 96px;width: 192px;border: 1px solid #B1B1B4;border-radius: 7px;'>
                                        <p style='opacity: 0.9;color: #4A4A4A; font-family: Helvetica Neue;font-size: 9px;letter-spacing: 0;line-height: 12px;padding: 5px;margin: 0;'>" .$contentP[2]['usable']['nxt']. "</p>
                                    </div>
                                </div>
                                    
                                </div>
                            </div>
                            <div style='text-align: center;margin-left:auto;margin-right:auto;margin-top:100px;' >
                            <hr style='color:#FEB103;height:1px;width:100%;margin-top:-5px;color:#707070;opacity: 0.4;'>
                            <p class='footer-styles'>This print-friendly automatically generated report is created by DMI for internal consumption only.© 2020 Siemens</p>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
              <!--landing 3 -->
              <div> 
                <div class = 'report-landing3' style='height:842px;width:85%;background-color: #FFFFFF;margin-left:auto;margin-right:auto;background-color: #FFFFFF;margin-top:1%;padding:30px 0 0 0;'>
                    <div class='report-header' style='display:block;'>
                    <div style='float:left;width:100px;'><img src='img/Report/report-logo.jpg'  width='80' height='32'/></div> 
                    <p  style='float:right;text-align:right;color: #4A4A4A;font-family:Helvetica Neue;font-size: 8px;letter-spacing: 0;line-height: 10px;margin:0;'>Self-Test taken on ".$time1." by ".$rowEmail['fname']."</p>
                    </div>
                    
                    <!-- para div1 --->
                    <div class='functional'>
                    <div style='margin-top:45px;'>
                       <span style='float:left;text-align:left;margin: 0;margin-right:10px;width:130px;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Relatedness</span>
                       <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:400px;margin-top:-15px;'> 
                    </div>
                        <div style='margin-top:40px;clear:both;'>
                            <div style='width:50%;float:left'>
                            <img  src=".$src." height='285' width='300' />
                            </div> 
                            <div style='width:50%';float:right;>
                                <span style='font-size: 26px;font-family: Helvetica Neue;letter-spacing: 0;line-height: 32px;text-align: right;color: #84CCC0;font-weight: bold;'>" . $finalResult['category'][3] . "<span style='font-size:12px;'>%</span></span>
                                <!-- <span style='font-size: 12px;font-family: Helvetica Neue;font-weight: bold;letter-spacing:0;line-height: 15px;margin-left: 5px;color: #9B9B9B;'>" .$contentP[3]['reliable']['label'] . "</span>
                                <img src='img/Report/" .$contentP[3]['reliable']['smiley'] . ".svg'  height='22' width='22' style='margin-left: 5px;margin-top:10px;display:inline-block;margin-bottom:0;'> -->
                                <p style=' line-height: 10px;margin: 0;font-size: 10px; height: 18px;color: #4A4A4A;font-family: Helvetica Neue Bold;font-weight: 500;
                                letter-spacing: 0;'><span style='border-bottom:1px solid #84CCC0;'>Relatedness Score</span> for ".$finalResult['product_name']." based on your response</p>
                                <div style='width:100%;padding-top:3px;'>
                                 <span style='float:left;text-align:left;margin: 0;width:110px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size: 10px;letter-spacing: 0;line-height: 10px;'>What does the score mean? </span>
                                 <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:185px;margin-top:-5px;'> 
                                </div>
                                <p style='color: #4A4A4A;font-family: Helvetica Neue;font-size:9px;font-weight: 500; letter-spacing: 0;line-height: 12px;margin: 0; height: 45px;margin-top:-5px;'>" .$contentP[3]['reliable']['comment']." </p>
                                <div style='padding-top: 10px;'>
                                <div style='width:100%;'>
                                <span style='float:left;text-align:left;margin: 0;width:110px;font-weight:bold;font-family:Helvetica Neue;color: #4A4A4A;font-size:10px;letter-spacing: 0;line-height: 10px;'>What's next? </span>
                                <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:240px;margin-top:-5px;'> 
                            </div>
                                    <div style='height: 96px;width: 192px;border: 1px solid #B1B1B4;border-radius: 7px;'>
                                        <p style='opacity: 0.9;color: #4A4A4A; font-family: Helvetica Neue;font-size: 9px;letter-spacing: 0;line-height: 12px;padding: 5px;margin: 0;'>" .$contentP[3]['reliable']['nxt']. "</p>
                                    </div>
                                </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div style='margin-top:50px;'>
                   <span style='float:left;text-align:left;margin: 0;width:102px;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Status</span>
                   <hr style='margin-left:10px;float:right;text-align:right;color:#84CCC0;height:1px;width:540px;margin-top:-15px;'> 
                   </div>
                   <div style='margin-top:45px;margin-bottom:50px;'>
                   <img src='img/Report/status.png' style='clear:both;height:105px;width:100%;left:30px;'/>
                   </div>
                            <!-- <div style='text-align: center;margin-left:auto;margin-right:auto;margin-top:350px;' >
                            <hr style='color:#FEB103;height:1px;width:100%;margin-top:-5px;color:#707070;opacity: 0.4;'>
                            <p class='footer-styles'>This print-friendly automatically generated report is created by UXMM for internal consumption only.© 2020 Siemens</p>
                            </div>
                            
                            <div class='report-header' style='display:block;margin-top:350px'>
                    <div style='float:left;width:100px;'><img src='img/Report/report-logo.jpg'  width='80' height='32'/></div> 
                    <p  style='float:right;text-align:right;color: #4A4A4A;font-family:Helvetica Neue;font-size: 8px;letter-spacing: 0;line-height: 10px;margin:0;'>Self-Test taken on ".$time1." by ".$rowEmail['fname']."</p>
                    </div> -->

                            <div style='margin-top:50px;'>
                            
                   <span style='float:left;text-align:left;margin: 0;width:202px;font-weight:bold;font-family:Helvetica Neue;color: #171717;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Contact XD Lab</span>
                   <hr style='margin-left:5px;float:right;text-align:right;color:#84CCC0;height:1px;width:400px;margin-top:-15px;'> 
                   </div>
                   <div style='margin-top:50px;'>
                    <div style='float:left;clear:both;width:333px;'>
                    <img src='img/Report/Circle_pdf.png' style='clear:both;height:170px;left:30px;margin-top:20px;'/>
                    </div>
                    <div style='float:right;width:252px;'>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color: #4A4A4A;'>We at XD Lab | CT RDA SSI UXD-IN pride ourselves in being a
                       multi-disciplinary experience design team with a strong design innovation in our DNA. We are an end-to-end experience design team aiming to make technologies work for humans with best-in-class experiences.</p>
                      <p style='letter-spacing:0;line-height:15px;font-size:10px;font-weight:500;font-family:Helvetica Neue;color: #4A4A4A;margin-top:20px;margin-bottom:0;'>Ramesh Manickam </p>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;margin-bottom:0;margin-top:0;'>Senior Key Expert, XD Lab | CT RDA SSI UXD-IN</p>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;margin-bottom:0;margin-top:0;'>Email: ramesh.manickam@siemens.com</p>
                      <div>
                      <div style='float:left; width:220px;'>
                      <span style='display:inline-block;'><img style='height:8px;width:5px;display:inline-block;margin-right:5px;' src='img/Report/smartphone.svg' /><span style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;'>+91 (80) 3313 1628</span></span>
                      <span style='display:inline-block;'><img style='height:8px;width:5px;display:inline-block;margin-right:5px;margin-left:15px;' src='img/Report/Phone.svg' /><span style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;'>+91 984 044 6014</span></span>
                     </div>
                     <div style='float:right;text-align:right;'>
                     <a style='cursor:pointer;' href='https://www.yammer.com/siemens.com/#/threads/inGroup?type=in_group&feedId=352231424&view=all' target='_blank'><img src='img/Report/yammer_report.svg' style='height:35px;width:35px;'/></a>
                     </div>
                      </div>
                    </div>
                   </div>
                   <div style='text-align: center;margin-left:auto;margin-right:auto;margin-top:5px;'>
                   <hr style='color:#FEB103;height:1px;width:100%;margin-top:-5px;color:#707070;opacity:0.4;'>
                   <p class='footer-styles'>This print-friendly automatically generated report is created by DMI for internal consumption only.© 2020 Siemens.</p>
                   </div>

                        </div>
                    </div>      
                </div> 
              </div>  
              <!--landing 4-->
             
                   <!-- <div style='margin-top:50px;'>
                   <span style='float:left;text-align:left;margin: 0;width:102px;font-weight:bold;font-family:Helvetica Neue;color: #707070;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Status</span>
                   <hr style='margin-left:10px;float:right;text-align:right;color:#FEB103;height:1px;width:540px;margin-top:-15px;'> 
                   </div>
                   <div style='margin-top:45px;'>
                   <img src='img/Report/Status Cards@2x.png' style='clear:both;height:105px;width:100%;left:30px;'/>
                   </div> -->
                   <!-- <div style='margin-top:250px;'>
                   <span style='float:left;text-align:left;margin: 0;width:202px;font-weight:bold;font-family:Helvetica Neue;color: #707070;font-size: 30px;letter-spacing: 0;line-height: 37px;'>Contact XD Lab</span>
                   <hr style='margin-left:5px;float:right;text-align:right;color:#FEB103;height:1px;width:400px;margin-top:-15px;'> 
                   </div>
                   <div style='margin-top:50px;'>
                    <div style='float:left;clear:both;width:333px;'>
                    <img src='img/Report/Circle_pdf.png' style='clear:both;height:170px;left:30px;margin-top:20px;'/>
                    </div>
                    <div style='float:right;width:252px;'>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color: #4A4A4A;'>We at XD Lab | CT RDA SSI UXD-IN pride ourselves in being a
                       multi-disciplinary experience design team with a strong design innovation in our DNA. We are an end-to-end experience design team aiming to make technologies work for humans with best-in-class experiences.</p>
                      <p style='letter-spacing:0;line-height:15px;font-size:10px;font-weight:500;font-family:Helvetica Neue;color: #4A4A4A;margin-top:20px;margin-bottom:0;'>Ramesh Manickam </p>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;margin-bottom:0;margin-top:0;'>Senior Key Expert, XD Lab | CT RDA SSI UXD-IN</p>
                      <p style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;margin-bottom:0;margin-top:0;'>Email: ramesh.manickam@siemens.com</p>
                      <div>
                      <div style='float:left; width:220px;'>
                      <span style='display:inline-block;'><img style='height:8px;width:5px;display:inline-block;margin-right:5px;' src='img/Report/smartphone.svg' /><span style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;'>+91 (80) 3313 1628</span></span>
                      <span style='display:inline-block;'><img style='height:8px;width:5px;display:inline-block;margin-right:5px;margin-left:15px;' src='img/Report/Phone.svg' /><span style='letter-spacing:0;line-height:15px;font-size:8px;font-family:Helvetica Neue;color:#4A4A4A;'>+91 984 044 6014</span></span>
                     </div>
                     <div style='float:right;text-align:right;'>
                     <a style='cursor:pointer;' href='https://www.yammer.com/siemens.com/#/threads/inGroup?type=in_group&feedId=352231424&view=all' target='_blank'><img src='img/Report/yammer_report.svg' style='height:35px;width:35px;'/></a>
                     </div>
                      </div>
                    </div>
                   </div>
                   <div style='text-align: center;margin-left:auto;margin-right:auto;margin-top:5px;'>
                   <hr style='color:#FEB103;height:1px;width:100%;margin-top:-5px;color:#707070;opacity:0.4;'>
                   <p class='footer-styles'>This print-friendly automatically generated report is created by UXMM for internal consumption only.© 2020 Siemens.</p>
                   </div> -->
                   
                 </div>
              </div>
                
              </body>
    
    
    </html>");
    $time = date('ymdhis');

     $pdfReprotname = $finalResult['product_name'] . ' ' . $time;
   
  $mpdf->Output('/var/www/html/DMI/pdf/' . $pdfReprotname . '.pdf','F');
 // $mpdf->Output('C:/xampp/htdocs/UXMM/api/img/UXMM/' . $pdfReprotname . '.pdf','F');
 
   
   
//    $pdfLink = 'http://172.16.152.36/pdf/'.$time.'.pdf';
    $message="<html xmlns='https://www.w3.org/1999/xhtml' xmlns:v='urn:schemas-microsoft-com:vml'
    xmlns:o='urn:schemas-microsoft-com:office:office'>

<head>
    <!--[if gte mso 9]><xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
    </xml><![endif]-->
    <title>DMI Email</title>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0 '>
    <meta name='format-detection' content='telephone=no'>
    <!--[if !mso]><!-->
    <link href='https://db.onlinewebfonts.com/c/0e6de1ec911a2e267ff136bbdd384a44?family=Helvetica+Neue' rel='stylesheet'
        type='text/css' />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet'>
    <!--<![endif]-->
    <style type='text/css'>
    <style type='text/css'>
    body {
  margin: 0 !important;
  padding: 0 !important;
  -webkit-text-size-adjust: 100% !important;
  -ms-text-size-adjust: 100% !important;
  -webkit-font-smoothing: antialiased !important;
}
a {

    text-decoration: none;

}
  </style>
    </style>
</head>
<body width='680' style='width:680px;margin:auto;'>
    <div class='body-wrapper' style='width:680px;background-color: #fff;'>
        <table align='center' width='680px' border='0' cellspacing='0' class='em_main_table' style='width:680px;'>
            <th style='height:7px; background-color: #FEB103;Width:680px'></th>
            <tbody>
                <tr>
                    <td valign='top' align='center'>
                        <table class='em_main_table' style='width:568px;'  width='568'
                            cellspacing='0' cellpadding='0' border='0'>
                            <!--Header section-->
                            <tbody>
                                <td class='em_h20' style='font-size:0px; line-height:0px; height:32px;' height='32'>
                                    &nbsp;</td>
                                <tr>
                                    <td class='em_padd' valign='top'>
                                        <table style='width:558px;padding-bottom: 10px;border-bottom:1px solid #FEB103;'
                                            width='100%' cellspacing='0' cellpadding='0' align='center'>
                                            <tbody>
                                                <tr>
                                                    <td style='color:#707070;width:108px;font-family: helvetica neue;font-weight:bold; font-size:36px;text-align:-webkit-left' align='center'>
                                                        DMI </td>
                                                    <td style='color:#BDBDBD;font-size:14px;padding-left:10px;line-height:10px;font-family: helvetica neue;font-weight:bold;'>Digital Maturity</br>
                                                        Initiative </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <!--//Header section-->

                                <!--Content Text Section-->
                                <tr>
                                    <td style='font-size:0px; line-height:0px; height:25px;' height='25'>&nbsp;</td>
                                    <!--—this is space of 15px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <!-- <td style='font-size:0px; line-height:0px; height:35px;' height='30'>&nbsp;</td> -->
                                    <td style='width:558px' class='em_padd' width='558' valign='top' align='center'>
                                        <table width='558px;' cellspacing='0' cellpadding='0' border='0' align='center'>
                                            <tbody>
                                                <tr>
                                                    <td style='font-family:Arial, sans-serif; font-size:15px; line-height:24px;text-align:-webkit-left;color: #4F5A68;'
                                                        valign='top' align='left'>
                                                        Hello ".$rowEmail['fname']." ".$rowEmail['lname'].",
                                                        </td>
                                                </tr>
                                                <td style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                                    &nbsp;</td>
                                                <!--—this is space of 15px to separate two paragraphs ---->
                                </tr>
                                
                                <tr>
                                    <td style='font-family: Arial, sans-serif; font-size:15px; line-height:24px; color:#4F5A68; letter-spacing:0;width:558px;'
                                        valign='top' align='left'>
                                        Thank you for taking time for DMI Self-Test for <span style='font-family: Arial Bold'>".$finalResult['product_name']."</span>.
                                    </td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:15px; line-height:24px; color:#4F5A68; letter-spacing:0; width:558px;'
                                        valign='top' align='left'>
                                        The overall Experience Score of  <span style='font-family: Arial Bold'> ".$finalResult['product_name']."</span> is
                                        ".$finalResult['percentail']."% .
                                    </td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:15px; line-height:24px; color:#4F5A68; letter-spacing:0; width:558px;'
                                        valign='top' align='left'>
                                        DMI Self-Test is the first step to know the current status of Digital Maturity of </br>
                                       <span style='font-family: Arial Bold'> ".$finalResult['product_name']."</span>. The details are captured in the attached pdf,
                                         please have a look and let us know if you have any queries.
                                    </td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:25px;' height='25'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:10px;' height='10'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:15px; line-height:24px; color:#4F5A68; letter-spacing:0;'
                                        valign='top' align='left'>
                                        With Best Regards,</br>
                                        Ramesh Manickam,</br>
                                        Senior Key Expert,</br>
                                        XD Lab | CT RDA SSI UXD-IN</td>
                                </tr>
                                <tr>
                                    <td class='em_h20' style='font-size:0px; line-height:0px; height:70px;' height='70'>
                                        &nbsp;</td>
                                    <!--—this is space of 25px to separate two paragraphs ---->
                                </tr>
                                <tr>
                                    <td style='font-family:Arial, sans-serif; font-size:16px; line-height:24px; color:#4F5A68; letter-spacing:0;'
                                        valign='top' align='center'>
                                        Want to explore further?</td>
                                </tr>
                </tr>
                <tr>
                    <td class='em_h20' style='font-size:0px;line-height:0px;height:12px;' height='12'>&nbsp;</td>
                    <!--—this is space of 25px to separate two paragraphs ---->
                </tr>
               
                
                <table style='width:257px;color:#FFFFFF;'
                width='257' cellspacing='0' cellpadding='0' align='center'>
                <tbody>
                    <tr>
                        <td style='font-family: helvetica neue;font-weight:bold; font-size:15px;text-decoration: none;line-height:18px; color:#FFFFFF; letter-spacing:0;border-radius: 7px;-webkit-border-radius: 7px;-ms-border-radius: 7px;'
                        valign='middle' align='center' height='50' width='257' bgcolor='#FEB103'>
                       <a href='http://132.186.158.154/DMI/thank-page.html?".$_POST['user_id']."&".$rowEmail['email']."+".$_POST['product_id']."'  target='_blank' color='#FFFFFF' style='color: #ffffff; font-size:15px; font-weight: bold;text-decoration: none;line-height:40px; width:100%; display:inline-block;border-radius: 7px;-webkit-border-radius: 7px;-ms-border-radius: 7px;'>
                        <span style='color: #FFFFFF; text-decoration:none;'>GET IN TOUCH WITH XD LAB</span></a>
                    </td>
                    </tr>
                </tbody>
            </table>
                <tr>
                    <td class='em_h20' style='font-size:0px; line-height:0px; height:75px;' height='75'>&nbsp;</td>
                    <!--—this is space of 25px to separate two paragraphs ---->
                </tr>
                <tr>
                    <td style='font-family:Arial, sans-serif; font-size:24px; line-height:24px; letter-spacing:0;text-decoration:none;'
                        valign='top' align='center'>
                        <a href='https://www.yammer.com/siemens.com/#/threads/inGroup?type=in_group&feedId=352231424&view=all' target='_blank' style='cursor: pointer;text-decoration:none;'><img src='https://upload.wikimedia.org/wikipedia/commons/1/1f/Yammer_logo.png' style='display:block;' height='35' width='35' class=''></a>
                    </td>
                </tr>
                </tr>
            </tbody>
        </table>
        </td>
        </tr>

        <!--//Content Text Section-->
        <!--Footer Section-->
        <tr>
            <td style='font-family:Arial, sans-serif; font-size:11px; line-height:18px; color:#999999;' valign='top'
                align='center' height='15'>
            </td>
        </tr>
        <tr>
            <td style='font-family: Arial, sans-serif; font-size:11px; line-height:18px; color:#999999;' valign='top'
                align='center'>
                
            </td>
        </tr>
        <tr>
            <td style='font-family:helvetica neue;font-weight:bold;font-size:8px; opacity:.8;line-height:18px;border-bottom:1px solid #4a4a4a;' valign='top'
                align='center'>
                 
            </td>
        </tr>
        
        <tr>
            <td style='font-family: helvetica neue;font-size:8px; line-height:10px; color:#707070;opacity: .8;width:550px;text-decoration:none;padding-top:5px;' valign='top'
                align='center'>
                Disclaimer : Digital Maturity being a subjective topic, the score and results provided by DMI are high-level and can be used as a general indicator of the </br> digital maturity of 
                an initiative. The results and information in its current form are for internal references only and not for external or commercial use.
            </td>
        </tr>
        <tr>
            <td class='em_h20' style='font-size:0px; line-height:0px; height:10px;' height='10'>&nbsp;</td>
            <!--—this is space of 25px to separate two paragraphs ---->
        </tr>
        <tr>
        <td style='font-family: helvetica neue;font-size:7px; line-height:10px;text-decoration: none; color:#707070;opacity: .8;width:600px;' valign='top'
            align='center'>
            This print-friendly automatically generated report is created by DMI for internal consumption only.© 2020 Siemens.</a>
        </td>
    </tr>
        <tr>
            <td class='em_h20' style='font-size:0px; line-height:0px; height:35px;' height='35'>&nbsp;</td>
            <!--—this is space of 25px to separate two paragraphs ---->
        </tr>
        </tbody>
        </table>
        </td>
        </tr>
        <tr>
            <td class='em_h20' style='font-size:0px; line-height:0px; height:50px;' height='50'>&nbsp;</td>
        </tr>
        </tbody>
        </table>
        </td>
        </tr>
        </tbody>
        </table>
    </div>
</body>

</html>";
//    $mpdf->Output('/var/www/madhu_inst/public_html/siemens/pdf/MyPDF-test2.pdf', 'F');

//    file_put_contents('/var/www/madhu_inst/public_html/siemens/pdf/' . $time . '.pdf', $output);

   $genMethod->sendMails($rowEmail['email'], 'Siemens-DMI Report', $message, $pdfReprotname, false, false);
    $aList[JSON_TAG_STATUS] = 0;
}

function save_image_file( $base64, $upload_dir ){
    
    $needle = strpos( $base64, ',' );

    if ( $needle !== false ) {
        $base64  = substr( $base64, $needle + 1 );
        $base64    = base64_decode( $base64 );
        $uid     = uniqid();
        $file    = $uid;
        $success = file_put_contents( $upload_dir . '/' . $file.'.png', $base64 );
        return $success ? $uid : false;
    }
    
//    return false;
}

?>
