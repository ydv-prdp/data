<?php
/*
  Module                      : General
  File name                   : GeneralMethod.php
  Description                 : General utility functions
 */

class GeneralMethod {

    //put your code here
    public function __construct() {
        
    }

    /*
      Functoin            : statusHandler()
      Brief               : Function to handle JSON_TAG_STATUS
      Details             : Function to handle JSON_TAG_STATUS
      Input param         : 
      Input/output param  : 
      Return              :
      */

      public function statusHandler($aList){
        
        $statusCode = $aList[JSON_TAG_STATUS];
        $aResult = array();

        switch ($statusCode) {
          case 1:
              // Function to set the header on server error
               $aResult = $this->httpStatusServer();
            break;
          case 2:
              //Function for result response on failure with error code and description
                $aResult = $this->responseResult(ERRCODE_CLIENT, MANDATORY_FIELD_REQUIRED);
            break;
          case 3:
                // Function for respond on custom messages
                $aResult = $this->responseResult(ERRCODE_CLIENT, $aList[JSON_TAG_CUSTOM_MSG]);
            break;
          default:
                $aResult = $this->responseResult(ERRCODE_ERROR, ERROR_DEFAULT);
        }
        return $aResult;

      }


    /*
      Function            : generateResult($response, $bodyData)
      Brief               : Function used to display the result in json format.
      Details             : Function used to display the result in json format.
      Input param         : res - result in array
      Input/output param  : Nil
      Return              : Outputs Json data
     */

    public function generateResult($response, $aList, $status_code = 200) {
    
    if ($aList[JSON_TAG_STATUS] == 0) {
      //  print_r( $aList);
          $aResult = array(
              JSON_TAG_STATUS   => JSON_TAG_SUCCESS,
              JSON_TAG_RECORDS  => $aList[JSON_TAG_RESULT]
            );
      } else{
          $aResult = $this->statusHandler($aList);
          $status_code = ERRCODE_CLIENT;
      }

      return $response->withStatus($status_code)
        ->withHeader('Content-Type', JSON_TAG_CONTENT_JSON)
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->write(json_encode($aResult));
    }
    
    public function generateResult1($inaRes) {
        $Req = \Slim\Slim::getInstance();
        $Req->contentType('application/json');
        echo json_encode($inaRes);
    }


    /*
      Function            : paramMissing($instance)
      Brief               : Function for Missing Param
      Details             : Function for Missing Param
      Input param         : $response
      Return              : Returns array.
     */      
    public function paramMissing($response){
        $result = array(JSON_TAG_STATUS => JSON_TAG_ERROR,
                        JSON_TAG_DESC => INSUFFICIENT_PARAM);
        return $response->withStatus(ERRCODE_CLIENT)
        ->withHeader('Content-Type', JSON_TAG_CONTENT_JSON)
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->write(json_encode($result));
    } 


     /*
      Function            : httpStatusServer()
      Brief               : Function to set the header for server error
      Details             : Function to set the header for server error
      Input param         : Nil
      Input/output param  : $aResult
      Return              : Returns array.
     */    
    public function httpStatusServer(){
        $aResult = array(JSON_TAG_STATUS => JSON_TAG_ERROR,
                JSON_TAG_DESC => SERVER_EXCEPTION
              );
        return $aResult;
    }  


    /*
      Function            : responseResult($errorCode,$errorDesc)
      Brief               : Function for result response for failure
      Details             : Function for result response for failure with error code and description
      Input param         : $errorCode,$errorDesc
      Input/output param  : $aResult
      Return              : Returns array.
     */    
    public function responseResult($errorCode,$errorDesc){
        $aResult = array(JSON_TAG_STATUS => JSON_TAG_ERROR,
                  JSON_TAG_DESC => $errorDesc);
        // $this->httpStatus(ERRCODE_CLIENT_REFUSED);   
        return $aResult;
     }


    /*
      Function            : decodeJson($injData)
      Brief               : Function used to decode input json.
      Details             : Function used to decode input json.
      Input param         : Json data
      Input/output param  : Nil
      Return              : Outputs array
     */

    public function decodeJson($injData) {
        $bvalid = true;
        if ($injData == "" || !$injData) {
            $bvalid = false;
        } else {
            $aDecoded = json_decode($injData, true);
            if (!is_array($aDecoded))
                $bvalid = false;
        }

        if ($bvalid)
            return $aDecoded;
        else {
            return array(
                JSON_TAG_TYPE => JSON_TAG_ERROR,
                JSON_TAG_CODE => NULL,
                JSON_TAG_DESC => INVALID_JSON,
                JSON_TAG_ERRORS => array()
            );
        }
    }

    /*
      Function            : bCrypt($insPassword, $sSalt)
      Brief               : Function used to encode the password into BCrypt format.
      Details             : Function used to encode the password into BCrypt format using the salt data from database.
      Input param         : $insPassword - input password, $sSalt - salt data retrieved from database.
      Input/output param  : Nil
      Return              : Outputs hashed password.
     */

    public function bCrypt($insPassword, $sSalt) {

        //This string tells crypt to use blowfish for 5 rounds.
        $Blowfish_Pre = '$2a$05$';
        $Blowfish_End = '$';
        $bcrypt_salt = ($Blowfish_Pre . $sSalt . $Blowfish_End);

        $hashed_password = crypt($insPassword, $bcrypt_salt);
        return $hashed_password;
    }

    /*
      Function            : createHashedPassword($sPassword)
      Brief               : Function used to create hashed password.
      Details             : Function used to create hashed password.
      Input param         : $sPassword - password
      Input/output param  : Nil
      Return              : Outputs hashed password.
     */

    public function createHashedPassword($sPassword) {

        $aData = array();
        $Blowfish_Pre = '$2a$05$';
        $Blowfish_End = '$';

        $Allowed_Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789./';
        $Chars_Len = 63;

        // 18 would be secure as well.
        $Salt_Length = 21;

        //$mysql_date = date('Y-m-d');
        $salt = "";

        for ($i = 0; $i < $Salt_Length; $i++) {
            $salt .= $Allowed_Chars[mt_rand(0, $Chars_Len)];
        }
        $bcrypt_salt = $Blowfish_Pre . $salt . $Blowfish_End;

        $hashed_password = crypt($sPassword, $bcrypt_salt);
        $aData['hashedPass'] = $hashed_password;
        $aData['salt'] = $salt;

        return $aData;
    }

    /*
      Function            : generateUUID()
      Brief               : Function used to generate UUID.
      Details             : Function used to generate UUID.
      Input param         : Nil
      Input/output param  : Nil
      Return              : Outputs UUID v4.
     */

    public function generateUUID() {

        // http://www.php.net/manual/en/function.uniqid.php#94959

        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                // 32 bits for "time_low"
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                // 16 bits for "time_mid"
                mt_rand(0, 0xffff),
                // 16 bits for "time_hi_and_version",
                // four most significant bits holds version number 4
                mt_rand(0, 0x0fff) | 0x4000,
                // 16 bits, 8 bits for "clk_seq_hi_res",
                // 8 bits for "clk_seq_low",
                // two most significant bits holds zero and one for variant DCE1.1
                mt_rand(0, 0x3fff) | 0x8000,
                // 48 bits for "node"
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    /*
      Function            : sanitizeString($insString)
      Brief               : Function used to sanitize input string.
      Details             : Function used to sanitize input string.
      Input param         : String
      Input/output param  : Nil
      Return              : Outputs sanitized string.
     */

    public function sanitizeString($insString) {
       $insString = strip_tags($insString); 
        if (get_magic_quotes_gpc())
            $insString = stripslashes($insString);
        $insString =  trim($insString);
        return $insString;
    }

    /*
      Function            : isValidDate( $postedDate )
      Brief               : Function used to check date.
      Details             : Function used to check date.
      Input param         : String
      Input/output param  : Nil
      Return              : bool
     */

    public function isValidDate($postedDate) {
        if (preg_match('/^[0-9]{4}-([0-9]|0[1-9]|1[0-2])-([0-9]|0[1-9]|[1-2][0-9]|3[0-1])$/', $postedDate)) {
            list($year, $month, $day) = explode('-', $postedDate);
            return checkdate($month, $day, $year);
        } else {
            return false;
        }
    }

    /*
      Function            : validateDate($date, $format = 'Y-m-d H:i:s')
      Brief               : Function used to check date.
      Details             : Function used to check date.
      Input param         : String
      Input/output param  : Nil
      Return              : bool
     */

     public function validateDate($date, $format = 'Y-m-d H:i:s') {
          $d = DateTime::createFromFormat($format, $date);
          return $d && $d->format($format) == $date;
      }
    /*
      Function            : isValidDatetime($dateTime)
      Brief               : Function used to check date time object
      Details             : Function used to check date time object
      Input param         : String
      Input/output param  : Nil
      Return              : bool
     */

    public function isValidDatetime($dateTime) {
        $matches = array();
        // if(preg_match("/^(\d{4})-(\d{2})-(\d{2}) ([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/", $dateTime, $matches)){
        if (preg_match("/^(\d{4})-([0-9]|0[1-9]|1[0-2])-([0-9]|0[1-9]|[1-2][0-9]|3[0-1]) ([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])$/", $dateTime, $matches)) {

            // print_r($matches); echo "<br>";
            $yy = trim($matches[1]);
            $mm = trim($matches[2]);
            $dd = trim($matches[3]);
            return checkdate($mm, $dd, $yy); // <- Problem here?
        } else {
//        echo "wrong format<br>";
            return false;
        }
    }


    /*
      Function            : isValidEmail($email)
      Brief               : Function used to verify email address
      Details             : Function used to verify email address, if valid, return true else false
      Input param         : array
      Input/output param  : Nil
      Return              : bool
     */

    public function isValidEmail($email) {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return TRUE;
        }
        else {
            return FALSE;
        }
    } 

    /*
      Function            : emptyElementExists($arr)
      Brief               : Function used to verify whether an array has null element.
      Details             : Function used to verify whether an array has null element.
      Input param         : array
      Input/output param  : Nil
      Return              : bool
     */

    public function emptyElementExists($arr) {
        //If one or more elements of an array contains null values then this function returns true.
        return array_search("", $arr) !== false;
    }

    
    function generateUniqueFileName($length = 12){
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        
        $uniqFileName = md5($randomString.time());
        
        return $uniqFileName;        
    }

    
    function generateUniqueQRKey() {
        
        $uniqKey = md5(uniqid().time());
        
        return $uniqKey;
    }


    //To create associate keys 
    function assoc_by($key, $array) {
        $new = array();
        foreach ($array as $v) {
            if (!array_key_exists($v[$key], $new))
                $new[$v[$key]] = $v;
        }
        return $new;
    }  


    public function simple_crypt( $string, $action = 'e' ) {
   
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', ENC_SECRET_KEY );
        $iv = substr( hash( 'sha256', ENC_SECRET_IV ), 0, 16 );
     
        if( $action == 'e' ) {
            $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
        }
        else {
            $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
        }        
     
        return $output;
    }

    public function sendMails($emailsArray,$subject,$message,$file,$isReferel,$isInterest)
    {
//        print_r($subject);
        require 'library/sendgrid-php/vendor/autoload.php';

//        $sendgrid = new SendGrid(SENDGRID_APIKEY);
//        $email = new SendGrid\Email();
//        print_r($subject);
//
//        //To send to multiple emails can use ->setTos(array of emails)
//        //        ->addTo("test@sendgrid.com")
//        $email->setSmtpapiTos($emailsArray)
//            ->setFrom("test@cumulations.com")
//            ->setFromName('Siemens UXMM')
//            ->setSubject($subject)
//            ->setHtml($message)
////            ->setAttachment('/var/www/madhu_inst/public_html/siemens/pdf/'.$file.'.pdf');
//            ->setAttachment('/var/www/html/pdf/'.$file.'.pdf');
//
//
//        try {
//            $sendgrid->send($email);
//            print_r('success');
//            return 'success';
//
//        } catch (\SendGrid\Exception $e) {
//            print_r($e);
//            foreach($e->getErrors() as $er) {
//                echo $er;
//            }
//            return 'unsuccess';
//        }
//        require 'library/sendgrid-php/vendor/autoload.php';
//        print_r("i m 2");
//Dotenv::load(__DIR__);
        $sendgrid_apikey = "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";
        $sendgrid = new SendGrid($sendgrid_apikey);
        $url = 'https://api.sendgrid.com/';
//        $pass = $sendgrid_apikey;
//        $template_id = '<your_template_id>';
//$js = array(
//  'sub' => array(':name' => array('Elmer')),
        // 'filters' => array('templates' => array('settings' => array('enable' => 1, 'template_id' => $template_id)))
//);
//$filePath='/var/www/html/UXMM/pdf/'.$file.'.pdf';
$filePath= 'C:/xampp/htdocs/UXMM/api/img/UXMM/'.$file.'.pdf';
if(!$isReferel && !$isInterest){
    
        $params = array(
            'to'        => $emailsArray,
            //'from'      => "praveen.kumars.ext@siemens.com",
            'from'   => "experiencedesign.ct@siemens.com",
            //'fromname'  => "Siemens UXMM",
           'cc'        => "experiencedesign.ct@siemens.com",
            'addBcc'    => "experiencedesign.ct@siemens.com",
            'subject'   => $subject,
            'html'      => $message,
            'files['.$file.'.pdf]' => file_get_contents($filePath)
        );  
}elseif($isReferel && !$isInterest){
    $params = array(
        'to[0]'        => $emailsArray[0],
        'to[1]'        => $emailsArray[1],
        'to[2]'        => $emailsArray[2],
       // 'from'         => "praveen.kumars.ext@siemens.com",
        'from'       => "experiencedesign.ct@siemens.com",
        //'fromname'  => "Siemens UXMM",
        'cc'        => "experiencedesign.ct@siemens.com",
        'addBcc'    => "experiencedesign.ct@siemens.com",
        'subject'   => $subject,
        'html'      => $message
    );
}elseif(!$isReferel && $isInterest){
   
    echo "<script>console.log('here in else') </script>"; 
    $params = array(
        'to'        => $emailsArray,
        'from'      => "experiencedesign.ct@siemens.com",
        'subject'   => $subject,
        'html'      => $message
    );
}

        $request =  $url.'api/mail.send.json';

// Generate curl request
        $session = curl_init($request);

       // curl_setopt($session, CURLOPT_PROXY, '194.138.0.62:9400');
       // curl_setopt($session, CURLOPT_PROXY, '194.138.0.63:9400');
       // curl_setopt($session, CURLOPT_PROXY, '194.138.0.25:9400');
       // curl_setopt($session, CURLOPT_PROXY, '194.138.0.26:9400');



// Tell PHP not to use SSLv3 (instead opting for TLS)
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $sendgrid_apikey));
// Tell curl to use HTTP POST
        curl_setopt ($session, CURLOPT_POST, true);
// Tell curl that this is the body of the POST
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
// Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

// obtain response
        $response = curl_exec($session);
        curl_close($session);

// print everything out
        print_r($response);
        return $response;
    }

}

?>
