<?php
/*
  File name                   : UsersManager.php
  Description                 : UsersManager class for Users related activities
 */


class UsersManager {

    /*
      Function            : quest(Request $request, Response $response)
      Brief               : Function to get questions
      Details             : Function to get questions
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */
    public function quest($id){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $Qid            = $id['id'];

            if (empty($Qid)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            if($Qid > 16){
                $aList[JSON_TAG_CUSTOM_MSG] = "Id value range 1-16";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;

            }

            $sQuery = "SELECT id, question FROM questions WHERE id = :id AND is_deleted = 0";
            $db->query($sQuery);
            $db->bind(":id", $Qid);
            $row = $db->single();
//          print_r();


            $aList[JSON_TAG_RESULT] = $row;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//           print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }




    public function test(){
        $aList[JSON_TAG_RESULT] = "Succes";
        $aList[JSON_TAG_STATUS] = 0;
        return $aList;
    }
    /*
       Function            : answer(Request $request, Response $response)
       Brief               : Function to store the answer
       Details             : Function to store the answer
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function answer($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $inData[JSON_TAG_USER_ID];
            $p_id           = $inData[JSON_TAG_PRODUCT_ID];
            $q_id           = $inData[JSON_TAG_QUESTION_ID];

            $answer           = $inData[JSON_TAG_ANSWER];

            if (empty($p_id) || empty($q_id) || empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $sQuery = "SELECT a_id FROM survey_ans WHERE".
                " p_id = :p_id AND q_id = :q_id AND user_id = :userId AND is_deleted =0";

            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":q_id", $q_id);
            $db->bind(":userId", $userId);

            $row = $db->single();
            if(empty($row)){
                $sQuery = "INSERT INTO survey_ans (p_id, q_id, answer, added_on, updated_on)"
                    ." VALUES (:p_id, :q_id, :answer, NOW(), NOW())";
                $db->query($sQuery);
                $db->bind(":p_id", $p_id);
                $db->bind(":q_id", $q_id);
                $db->bind(":answer", $answer);

                $db->execute();

                $id = $db->lastInsertId();
            }
            else{
                $sQuery = "UPDATE survey_ans set answer=:answer ,updated_on= NOW() WHERE"
                    ." a_id = :a_id";
                $db->query($sQuery);
                $db->bind(":a_id", $row['a_id']);
                $db->bind(":answer", $answer);

                $db->execute();

                $id = $row['a_id'];
            }



            $aList[JSON_TAG_RESULT] = $id;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
            // print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }
    /*
       Function            : product(Request $request, Response $response)
       Brief               : Function to store the product-deatils
       Details             : Function to store the product-deatils
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function product($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $pName           = $genMethod->sanitizeString($inData[JSON_TAG_PRODUCT_NAME]);
//      $userId          = $inData[JSON_TAG_USER_ID];
            $version         = $genMethod->sanitizeString($inData[JSON_TAG_VERSION]);

            if (empty($pName) || empty($version) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }
//
//      $rowUser = $this->checkUserId($db, $userId);
//      if (empty($rowUser)) {
//        $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
//        $aList[JSON_TAG_STATUS] = 3;
//        return $aList;
//      }

            $rowProduct = $this->productName($db,$pName,$version);
            if(empty($rowProduct)){
                $sQuery = "INSERT INTO products (p_name, version, added_on, updated_on)"
                    ." VALUES (:p_name, :version, NOW(), NOW())";

                $db->query($sQuery);
                $db->bind(":p_name", $pName);
//        $db->bind(":user_id", $userId);
                $db->bind(":version", $version);

                $db->execute();

                $id = $db->lastInsertId();
            }else{
                $id = $rowProduct['p_id'];
            }



            $aList[JSON_TAG_RESULT] = $id;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
        Function            : quest(Request $request, Response $response)
        Brief               : Function to get questions
        Details             : Function to get questions
        Input param         : Nil
        Input/output param  : Array
        Return              : Returns array.
       */
    public function getProd($id){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $p_id            = $id['id'];

            if (empty($p_id)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }
            $rowProduct = $this->getProductname($db,$p_id);
            if(! empty($rowProduct)){
                $aList[JSON_TAG_RESULT] = $rowProduct;
                $aList[JSON_TAG_STATUS] = 0;
            }else{
                $aList[JSON_TAG_CUSTOM_MSG] = "Invalid Id";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }


//          print_r();




        } catch (Exception $e) {
//           print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
       Function            : user(Request $request, Response $response)
       Brief               : Function to store the user-deatils
       Details             : Function to store the user-deatils
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function user($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $fName           = $genMethod->sanitizeString($inData[JSON_TAG_FNAME]);
            $userId          = $inData[JSON_TAG_USER_ID];
            $lName         = $genMethod->sanitizeString($inData[JSON_TAG_LNAME]);
            $role           = $genMethod->sanitizeString($inData[JSON_TAG_ROLE]);

            if (empty($fName) || empty($userId) || empty($lName) || empty($role) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $sQuery = "UPDATE users SET fname = :fname, lname = :lname, role =:role, updated_on = NOW()".
                "WHERE user_id =:user_id";

            $db->query($sQuery);
            $db->bind(":fname", $fName);
            $db->bind(":lname", $lName);
            $db->bind(":role", $role);
            $db->bind(":user_id", $userId);
            $update=$db->execute();
            if($update){
                $aList[JSON_TAG_RESULT] = 'Updated';
            }else{
                $aList[JSON_TAG_RESULT] = 'Error in Updating';
            }

//      $id = $db->lastu

//      $aList[JSON_TAG_RESULT] = $update;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
       Function            : answerNew(Request $request, Response $response)
       Brief               : Function to store the answer
       Details             : Function to store the answer
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function answerNew($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $inData[JSON_TAG_USER_ID];
            $p_id           = $inData[JSON_TAG_PRODUCT_ID];
            $q_id           = $inData[JSON_TAG_QUESTION_ID];

            $answer           = $inData[JSON_TAG_ANSWER];

            if (empty($p_id) || empty($q_id) || empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }
            $colName = $this->getQuestionField($db,$q_id);
            $colValue = $colName['field'];

            if($answer == '6'){
                $answer = '0';
            }
//      print_r($colValue);
//      exit();

            $sQuery = "SELECT a_id FROM answers WHERE".
                " p_id = :p_id AND user_id = :userId AND is_deleted =0";

            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":userId", $userId);
            $row = $db->single();
//      print_r("value is =".$row);
//      exit();
            if(empty($row)){
//        print_r("value is null");
                $sQuery = "INSERT INTO answers (p_id, user_id, ".$colValue.", added_on, updated_on)"
                    ." VALUES (:p_id, :user_id, :answer, NOW(), NOW())";
                $db->query($sQuery);
                $db->bind(":p_id", $p_id);
                $db->bind(":user_id", $userId);
                $db->bind(":answer", $answer);
                $db->execute();
                $id = $db->lastInsertId();
            }
            else{
                $sQuery = "UPDATE answers set ".$colValue."=:answer, updated_on= NOW() WHERE"
                    ." a_id = :a_id";
                $db->query($sQuery);
                $db->bind(":a_id", $row['a_id']);
                $db->bind(":answer", $answer);
                $db->execute();
                $id = $row['a_id'];
            }



            $aList[JSON_TAG_RESULT] = $id;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
     Function            : addUser(Request $request, Response $response)
     Brief               : Function to add the user
     Details             : Function to add the user
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function addUser($inData){
        //print_r($inData);
        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $email           = $genMethod->sanitizeString($inData[JSON_TAG_EMAIL]);


            if (empty($email)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            if (!$genMethod->isValidEmail($email)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "invalid email address";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }


            $sQuery = "INSERT INTO users (email, added_on, updated_on)"
                ." VALUES (:email, NOW(), NOW())";

            $db->query($sQuery);
            $db->bind(":email", $email);

            $db->execute();

            $id = $db->lastInsertId();

            $aList[JSON_TAG_RESULT] = $id;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
           // print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }


    // feeback

       public function feedback($inData){
        
        try{
            
            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $product_id      =  $inData[JSON_TAG_PRODUCT_ID];
            $userId          =  $inData[JSON_TAG_USER_ID];
            $pName           =  $genMethod->sanitizeString($inData[JSON_TAG_PRODUCT_NAME]);
            $comment         =  $genMethod->sanitizeString($inData[JSON_TAG_COMMENT]);
            $helpful         =  $genMethod->sanitizeString($inData[JSON_TAG_HELPFUL]);
            //print_r($helpful);
            
            if (empty($product_id)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product id cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }
        
                $sQuery = "INSERT INTO feedback (p_id, user_id, p_name, comment, helpful)"
                    ." VALUES (:p_id, :user_id, :p_name, :comment, :helpful)";

                $db->query($sQuery);
                $db->bind(":p_id", $product_id);
                $db->bind(":user_id", $userId);
                $db->bind(":p_name", $pName);
                $db->bind(":comment", $comment);
                $db->bind(":helpful", $helpful);

                $db->execute();
                $id = $db->lastInsertId();   
                    
     }
        catch (Exception $e) {
        print_r($e);
        $aList[JSON_TAG_STATUS] = 1;
                }
        return $aList;
    }
    /*
     Function            : getAns(Request $request, Response $response)
     Brief               : Function to get the answer
     Details             : Function to get the answer
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */
    public function getAns($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $p_id           = $inData[JSON_TAG_PRODUCT_ID];
            $q_id           = $inData[JSON_TAG_QUESTION_ID];
            $userId          = $inData[JSON_TAG_USER_ID];

            if (empty($p_id) || empty($q_id)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $colName = $this->getQuestionField($db,$q_id);
            $colValue = $colName['field'];

            $sQuery = "SELECT p_id, ".$colValue." as answer FROM answers WHERE".
                " p_id = :p_id AND user_id = :user_id";

            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":user_id", $userId);
            $row = $db->single();

            if (empty($row)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "No data found";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

//      $id = $db->lastInsertId();
            $row['q_id'] =$q_id;
            $aList[JSON_TAG_RESULT] = $row;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
            // print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
       Function            : result(Request $request, Response $response)
       Brief               : Function to store the answer
       Details             : Function to store the answer
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function result($inData){
    
        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $inData[JSON_TAG_USER_ID];
            $p_id           = $inData[JSON_TAG_PRODUCT_ID];

            if (empty($p_id) || empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }
            $sQuery = "SELECT field FROM `questions` WHERE is_deleted = 0";
            $db->query($sQuery);
            $queField = $db->resultSet();

            $queAvg = [];

            $sQuery = "SELECT p_id FROM `products` WHERE is_deleted = 0";
            $db->query($sQuery);
            $productRow = $db->resultSet();
//      foreach ($productRow as $keyP => $valueP){
//        foreach ($queField as $keyQf => $valueqf){
//          $sQuery = "SELECT ROUND(AVG(".$valueqf['field']."),3) as ".$valueqf['field']."  FROM `answers` WHERE is_deleted = 0 GROUP BY p_id";
//          $db->query($sQuery);
//          $queAvg[] = $db->resultSet();
//
//        }
//        $arg = [];
//        $std =[];
//        foreach ($queAvg as $keyQa => $valueQa){
////          $average= array_sum($valueQa['q1']) / count($valueQa['q1']);
//          foreach ($valueQa as $rows => $data) {
//            foreach ($data as $key => $val) {
//              $arg[$key][] = $val;
//            }
//          }
//
//        }
//        foreach ($arg as $key1 => $val1){
//          $average[$key1]= array_sum($val1) / count($val1);
//        }
//
//      foreach ($arg as $key1 => $val1){
//        $average[$key1]= array_sum($val1) / count($val1);
//        foreach($val1 as $key2 => $num){
//          $devs[$key2] = pow($num - $average[$key1], 2);
//          $std[$key1] = round(sqrt(array_sum($devs) / (count($devs) - 1)),3);
//        }
//      }

            $sQuery = "SELECT * FROM answers WHERE is_deleted = 0 AND p_id = :p_id AND user_id = :user_id";
            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":user_id", $userId);
            $crtResp = $db->single();

            $notSelect = array('a_id','p_id','user_id','added_on','updated_on','is_deleted','flag','score');
            $currentresp = [];
            foreach ($crtResp as $kcr => $vcr){
                if(!in_array($kcr, $notSelect) && $vcr !=0){
//          print_r($vcr);
                    $currentresp[$kcr]= $vcr;
                }
            }
//       $currentAvg =  round(array_sum($currentresp) / count($currentresp),3);
//      $norm =[];

//      foreach ($average as $Kavg => $Vavg){
//        foreach ($std as $Kstd => $Vstd){
//          if($Kavg == $Kstd){
//            $norm[$Kavg]= round(($currentAvg-$Vavg)/$Vstd,3);
//          }
//        }
//      }
   //   print_r($currentresp);
            $allOne =0;
            $allFive =0;
            foreach ($currentresp as $keyHandle => $valueHandle){
                if($valueHandle == 1){
                    $allOne++;
                }elseif ($valueHandle == 5){
                    $allFive++;
                }
//        print_r($valueHandle);
//        exit();
            }
            $count= count($currentresp);
            $maxValue = $count*5;
            $percentail = Round((array_sum($currentresp)/$maxValue)*100,2);
//

            $sQuery = "SELECT field, category FROM questions WHERE is_deleted = 0 ";
            $db->query($sQuery);
            $catRow = $db->resultSet();

            $array1 =[];
            foreach ($catRow as $kcat => $vcat){
                $array1[$vcat['category']][]= $vcat['field'];
            }
//      print_r($array1);

            $keyhold =[];
            $quehold=[];
            foreach ($array1 as $keyArray => $valArray){
                foreach ($valArray as $keyVA => $valVA){
                    if(!empty($currentresp[$valVA])){
                        $tmp[]=$currentresp[$valVA];
                        $tmp1[$valVA]=$currentresp[$valVA];
                    }

//          print_r($tmp);
//          exit();
                }
                $keyhold[$keyArray]=$tmp;
                $quehold[$keyArray]=$tmp1;
                $tmp = [];
                $tmp1 = [];
            }
//print_r($keyhold);
//      print_r($quehold);

            $categoryPer = [];
            foreach ($keyhold as $khold => $vhold){
//        print_r(array_sum($vhold).'----------'.count($vhold));

                $categoryPer[$khold] = round( ((array_sum($vhold)/(5*count($vhold))) *100),2);
            }
            foreach ($categoryPer as $kNAN => $vNAN){
                if(is_nan($vNAN)){
                    $categoryPer[$kNAN] = 0;
//          print_r('nooo');
                }
            }
//      print_r($categoryPer);

//      $percentail = array_sum($categoryPer);
            $Prodname = $this->getProductname($db, $p_id);

//      print_r($keyhold);
//      print_r($categoryPer);
            $newsort = [];
//      print_r($quehold);
            foreach ($quehold as $kq => $vq){
//        print_r($vq);
//        foreach ($vq as $k1q => $v1q){
                arsort($vq);
                $newsort[$kq]= $vq;
//        print_r($vq);
//        exit();
//        }
            }
//      asort($quehold);
//      print_r($quehold);
//      print_r($newsort);
//      exit();
            $sQuery = "UPDATE answers set score=:score, updated_on= NOW() WHERE"
                ." a_id = :a_id";
            $db->query($sQuery);
            $db->bind(":a_id", $crtResp['a_id']);
            $db->bind(":score", $percentail);
            $db->execute();


            $finalResult =[];
            $finalResult['percentail']= round($percentail,1);
            $finalResult['category'] = $categoryPer;
            $finalResult['product_name'] = $Prodname['p_name'];
            $finalResult['version'] = $Prodname['version'];
//      print_r($finalResult['category']);
            $sortArray=[];
            $pArray=[];
            $nArray=[];
            $sortArray =$finalResult['category'];
            arsort($sortArray);
            if($allOne == $count){
//        $pArray=array_slice($sortArray, 0, 5, TRUE);
                $nArray=array_slice($sortArray, 0, 5, TRUE);
//        $pResp = "Your product is doing great in terms of";
                $nResp = "Your product needs immediate attention in terms of";
            }elseif ($allFive == $count){
                $pArray=array_slice($sortArray, 0, 5, TRUE);
//        $nArray=array_slice($sortArray, 3, 2, TRUE);
                $pResp = " Congratulations! Your product is doing really good in terms of";
//        $nResp = "Although your product has reached a considerable level of excellence, yet it can be improved in terms of";
            }else{
                $pArray=array_slice($sortArray, 0, 3, TRUE);
                $nArray=array_slice($sortArray, 3, 2, TRUE);
                $pResp = "Your product is doing great in terms of";
                $nResp = "Although your product has reached a considerable level of excellence, yet it can be improved in terms of";
            }


//      print_r($pArray);
//      exit();
            $pQuestion = [];
            foreach ($pArray as $keyS => $valS) {
                foreach ($newsort as $keyQ => $valQ) {
                    if ($keyS === $keyQ) {
//            print_r($keyQ);
                        foreach ($valQ as $kf => $vf){
//              print_r($kf);
                            $pQuestion []= $kf;
                            break;
                        }
//            continue;
                    }
                }
            }
//        print_r($pQuestion);
//
//
            foreach ($pQuestion as $kp => $vp){
                $sQuery = "SELECT positive FROM responses WHERE q_id = :q_id ORDER BY RAND() LIMIT 1";
                $db->query($sQuery);
                $db->bind(":q_id", $vp);
                $rowResp = $db->single();
                $pResp .=  " ".$rowResp['positive'].",";
            }
//      print_r($pResp);
//      exit();

//      }
            $nQuestion = [];
            foreach ($nArray as $keynS => $valnS) {
                foreach ($newsort as $keynQ => $valnQ) {
                    if ($keynS === $keynQ) {
                        asort($valnQ);
//            print_r($valnQ);
                        foreach ($valnQ as $knf => $vnf){
//              print_r($kf);
                            $nQuestion []= $knf;
                            break;
                        }
//            continue;
                    }
                }
            }
//      exit();
//      print_r($nQuestion);
//


            foreach ($nQuestion as $keyN => $valN){
                $sQuery = "SELECT negative FROM responses WHERE q_id = :q_id ORDER BY RAND() LIMIT 1";
                $db->query($sQuery);
                $db->bind(":q_id", $valN);
                $rowResp = $db->single();
                $nResp .=  " ".$rowResp['negative'].",";
            }
//      print_r($nResp);
//      exit();
            if($pResp != null){
                $finalResult['positive'] = substr_replace($pResp ,".",-1);
            }
            if($nResp != null){
                $finalResult['negative'] = substr_replace($nResp ,".",-1);
            }

//      echo(json_encode(array($finalResult)));
//      exit();
            $aList[JSON_TAG_RESULT] = $finalResult;
     
            $aList[JSON_TAG_STATUS] = 0;
           

        } catch (Exception $e) {
//      print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
       // print_r( $aList);
        return $aList;
    }


    /*
       Function            : result(Request $request, Response $response)
       Brief               : Function to store the answer
       Details             : Function to store the answer
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function interest($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $inData[JSON_TAG_USER_ID];
            $p_id           = $inData[JSON_TAG_PRODUCT_ID];

            if (empty($p_id) || empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $sQuery = "UPDATE answers set flag = '1', updated_on= NOW() WHERE"
                ." is_deleted = 0 AND p_id = :p_id AND user_id = :user_id";
            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":user_id", $userId);
//      $interest = $db->single();
            $interest =  $db->execute();
//      $id = $row['a_id'];

            $aList[JSON_TAG_RESULT] = $interest;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//           print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }


    /*
          Function            : allQuestions(Request $request, Response $response)
          Brief               : Function to get all questions
          Details             : Function to get all questions
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */
    public function allQuestions(){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $sQuery = "SELECT * FROM questions WHERE is_deleted = 0";
            $db->query($sQuery);
            $rowQues = $db->resultSet();
          print_r("$rowQues---", $rowQues);


            $aList[JSON_TAG_RESULT] = $rowQues;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//           print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    //-------------------------------------------------------dashboard--------------------------------------------------

    /*
       Function            : response(Request $request, Response $response)
       Brief               : Function to get the response-deatils
       Details             : Function to get the response-deatils
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function response($inData){

        function date_range($first, $last, $step = '+1 day', $output_format = 'Y-m-d' )
        {

            $dates = array();
            $current = strtotime($first);
            $lastt = strtotime($last);

            $crtdate = date('Y-m-d',strtotime($first));
            $lastdate = date('Y-m-d',strtotime($last));
//
//            if ($crtdate == $lastdate) {
            while ($current <= $lastt) {

                $dates[] = date($output_format, $current);
                $current = strtotime($step, $current);
            }
            return $dates;

//
        }

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();

            $index           = $genMethod->sanitizeString($inData[JSON_TAG_INDEX]);

            if (empty($index)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }
            $currentDate= date('Y-m-d');
            if($index =='1' || $index == '2'){
                if($index == '1'){
                    $prevDate= date('Y-m-d', strtotime('-7 days'));
                }elseif ($index == '2'){
                    $prevDate= date('Y-m-d', strtotime('-1 months'));
                }

                $period = date_range($prevDate, $currentDate, "+1 day", "Y-m-d");

                $currentDatetime = $currentDate." 23:59:00";
                $prevDatetime = $prevDate." 00:00:00";
//      print_r($period);
                $sQuery = "SELECT date(added_on)as added, COUNT(a_id) as responses FROM answers WHERE is_deleted=0 AND added_on BETWEEN :fromT AND :toT GROUP BY date(added_on)";
                $db->query($sQuery);
                $db->bind(":fromT", $prevDatetime);
                $db->bind(":toT", $currentDatetime);

                $row = $db->resultSet();

                $sQuery = "SELECT date(added_on)as added, COUNT(a_id) as interest FROM answers WHERE is_deleted=0 AND flag='1' AND added_on BETWEEN :fromT AND :toT GROUP BY date(added_on)";
                $db->query($sQuery);
                $db->bind(":fromT", $prevDatetime);
                $db->bind(":toT", $currentDatetime);
//      $db->bind(":user_id", $user_id);
                $rowInst = $db->resultSet();
            }
            else{
                $currentDate= date('Y-m-d');


                $sQuery = "SELECT date(added_on)as added FROM answers WHERE is_deleted=0 ORDER BY added_on ASC LIMIT 1";
                $db->query($sQuery);
                $prev = $db->resultSet();
                $prevDate= $prev[0]['added'];
//        print_r($prevDate);
//        exit();

                $period = date_range($prevDate, $currentDate, "+1 day", "Y-m-d");

                $currentDatetime = $currentDate." 23:59:00";
                $prevDatetime = $prevDate." 00:00:00";

                $sQuery = "SELECT date(added_on)as added, COUNT(a_id) as responses FROM answers WHERE is_deleted=0 AND added_on BETWEEN :fromT AND :toT GROUP BY date(added_on)";
                $db->query($sQuery);
                $db->bind(":fromT", $prevDatetime);
                $db->bind(":toT", $currentDatetime);

                $row = $db->resultSet();

                $sQuery = "SELECT date(added_on)as added, COUNT(a_id) as interest FROM answers WHERE is_deleted=0 AND flag='1' AND added_on BETWEEN :fromT AND :toT GROUP BY date(added_on)";
                $db->query($sQuery);
                $db->bind(":fromT", $prevDatetime);
                $db->bind(":toT", $currentDatetime);
//      $db->bind(":user_id", $user_id);
                $rowInst = $db->resultSet();
            }


            $array2      = [];
            $array1     = [];

            foreach ($row  as $key => $value){
                $array2[$value['added']][] = $value;
            }

            foreach ($rowInst  as $keyI => $valueI){
                $array1[$valueI['added']][] = $valueI;
            }
//      print_r($array1);
//      print_r($array2);

            ksort($array2);
//      foreach ($array2 as $keyArray => $valArray) {
//        if (array_key_exists($key, $pd_by_date)) {
//          $cd_combined[$key] = array_merge($value, $pd_by_date[$key]);
//        }
//      }
            foreach ($array2 as $keyI2 => $valueI2){
//        foreach ($array2 as $keyArray => $valArray){
                if(array_key_exists($keyI2, $array1)){
                    $array2[$keyI2][0]['interest']= $array1[$keyI2][0]['interest'];
                }else{
                    $array2[$keyI2][0]['interest']= '0';
                }


            }
//
//      print_r($array2);


            $array =[];
            foreach ($period  as $keyp => $valuep){
                if(!array_key_exists($valuep,$array2)){
                    $array2[$valuep]=array();
                }
            }
            ksort($array2);
//      foreach ($array1)
//      print_r($array2);
//      exit();
            foreach ($array2 as $k => $v){
                if(empty($v)){
                    $tmp = array("added" => $k, "responses" => "0","interest" => "0");
//          $tmp = array("booking_date" => $k, "seats" => "0");
//                    print_r($tmp);
//                    print_r($v);
                    $array2[$k] []=$tmp;
//                    array_insert($array[$k],0,$tmp);
//                    $tmp[]='';
                }

            }
            $finalArray1 =[];
            foreach ($array2 as $ky => $vy){
//                print_r($vy[0]['booking_date']);
//                exit();
                $tmp = [];
                $tmp['added'] = $newDate = date("d M", strtotime($vy[0]['added']));
                $tmp['responses'] = $vy[0]['responses'];
                $tmp['interest'] = $vy[0]['interest'];
                $finalArray1[] = $tmp;
            }

            $sQuery = "SELECT count(DISTINCT(p_id)) as product_count FROM answers WHERE is_deleted='0'";
            $db->query($sQuery);
//      $db->bind(":user_id", $user_id);
            $row = $db->resultSet();
            $finalArray =[];
            $finalArray['total_product'] = $row[0]['product_count'];
            $finalArray['graph_data'] = $finalArray1;
            //------ weekly activity---------
            $currentWeek=   date('Y-m-d', strtotime('-6 days'));
            $toDate= date('Y-m-d');
            $prevFrom = date('Y-m-d', strtotime('-13 days'));
            $prevTo = date('Y-m-d', strtotime('-7 days'));
//            print_r($currentWeek);
//            print_r($prevTo);
//            print_r($prevFrom);

            $sQuery = "SELECT COUNT(a_id) as currentweek FROM answers WHERE is_deleted=0 AND DATE(added_on) BETWEEN :lastweek AND :todate";
            $db->query($sQuery);
            $db->bind(":lastweek", $currentWeek);
            $db->bind(":todate", $toDate);
            $weekresp=$db->single();
            $weekresp= $weekresp['currentweek'];

            $sQuery = "SELECT COUNT(a_id) as prevweek FROM answers WHERE is_deleted=0 AND DATE(added_on) BETWEEN :prevweek AND :prevdate";
            $db->query($sQuery);
            $db->bind(":prevweek", $prevFrom);
            $db->bind(":prevdate", $prevTo);
            $prevweekresp=$db->single();
            $prevweekresp = $prevweekresp['prevweek'];
//            print_r('response--------------');
//            $weekresp = 7;
//            $prevweekresp = 14;
//            print_r(gettype($weekresp));
//            print_r($prevweekresp);
//            exit();
            if($weekresp != 0 && $prevweekresp != 0){

//                print_r('hi');
                $subtract = $weekresp - $prevweekresp;
                $changeper = ($subtract/$prevweekresp)* 100;
            }elseif ($weekresp == 0 && $prevweekresp == 0){
                $changeper =0;
            }elseif ($weekresp != 0 && $prevweekresp == 0){
                $changeper = $weekresp*100;
            }else{
                $changeper = $prevweekresp*100;
            }

//            print_r($changeper);
            $finalArray['weekly_activity'] = $weekresp;
            $finalArray['percentage'] = round($changeper,1);





//      $id = $db->lastu

            $aList[JSON_TAG_RESULT] = $finalArray;
//      $aList[JSON_TAG_RECORDS] = $row;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
       Function            : response(Request $request, Response $response)
       Brief               : Function to get the response-deatils
       Details             : Function to get the response-deatils
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
    public function pieGraph(){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();


            $sQuery ="SELECT sum(CASE WHEN (score<'25' AND score <>'null') then 1 else 0 end ) as range1,".
                " sum(CASE WHEN (score BETWEEN '25' AND '49' AND score <>'null') then 1 else 0 end )as range2,".
                " sum(CASE WHEN (score BETWEEN '50' AND '74' AND score <>'null')then 1 else 0 end) as range3,".
                "sum(CASE WHEN (score BETWEEN '75' AND '100' AND score <>'null')then 1 else 0 end) as range4 from".
                " answers WHERE is_deleted = 0";
            $db->query($sQuery);
            $graphData = $db->resultSet();


            $aList[JSON_TAG_RESULT] = $graphData;
//      $aList[JSON_TAG_RECORDS] = $row;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

    /*
       Function            : productList(Request $request, Response $response)
       Brief               : Function to get the product-deatils
       Details             : Function to get the product-deatils
       Input param         : Nil
       Input/output param  : Array
       Return              : Returns array.
      */
public function productList(){

    try{

      $genMethod      = new GeneralMethod();
      $db             = new ConnectionManager();


      $sQuery ="SELECT DISTINCT (a.p_id),p.p_name,p.version FROM answers as a".
          " JOIN products as p ON a.p_id=p.p_id WHERE a.is_deleted='0'";
      $db->query($sQuery);
      $plist = $db->resultSet();
//      print_r($plist);
      $pArray=[];
      foreach ($plist  as $key1 => $value1){
        $pArray[$value1['p_id']] = $value1;
      }
//      exit();

      foreach ($plist as $Pkey => $pvalue){
        $sQuery ="SELECT a.p_id,u.fname,u.user_id,u.lname,u.role,u.email,a.score,a.flag,a.added_on FROM answers as a".
            " LEFT JOIN users as u ON a.user_id=u.user_id WHERE a.p_id =:p_id AND a.is_deleted='0' ORDER BY a.added_on DESC";
        $db->query($sQuery);
        $db->bind(":p_id", $pvalue['p_id']);
        $Rlist[] = $db->resultSet();
      }
//print_r($Rlist);

      $pArray2=[];
      $newArray =[];

      foreach ($Rlist  as $key2 => $value2) {
        $newArray[$value2[0]['p_id']] = $value2;
      }

      foreach ($newArray as $newKey => $newValue){
//        print_r(sizeof($newValue));
//        print_r($newValue);
        if(sizeof($newValue) > 1){
          $sum = 0;
          $date = '';
          $name = '';
            $email = '';
          $flag = 0;
          $user_id = '';
          $p_id = 0;
          $resCount = sizeof($newValue);
          foreach ($newValue as $key12 => $value12){
            $sum += $value12['score'];
            $date .= strtok($value12['added_on'],' ').',';
            $name .= $value12['fname'].' '.$value12['lname'].',';
            $flag += $value12['flag'];
              $email .= $value12['email'].',';
//            $version .= $value12['version'].',';
            $p_id = $value12['p_id'];
            $user_id .= $value12['user_id'].',';
          }
          $avg= round($sum /sizeof($newValue),2);
//          $date1 = $date;
          $date= substr_replace($date ,"",-1);
          $dateTo = strtok($date,',');

          $pj = substr($date, strrpos($date, ',' )+1);
          $dateFinal = $dateTo.','.$pj;
            $emailArray = explode(",",$email);
            $email = implode(',',array_unique($emailArray));

//          $dateFrom = strrpos($date,',');
          $pArray2[$p_id]=array("p_id" =>$p_id, "score" => $avg, "added_on" => $dateFinal,"names" => $name,"email" => $email, "flag" => $flag, "count" => $resCount, "user_id" => $user_id);
//

        }else{
          $newValue[0]['names']= $newValue[0]['fname'].' '.$newValue[0]['lname'];
          unset($newValue[0]['fname']);
          unset($newValue[0]['lname']);
          $pArray2[$newValue[0]['p_id']] = $newValue[0];
//          print_r($pArray2);
//          exit();
//          $pArray2[$newValue[0]['names']]=
        }
      }
//      print_r($pArray2);
      $result=[];


      foreach ($pArray  as $keyp => $valuep){
        if(array_key_exists($keyp,$pArray2)){
          $result[$pArray2[$keyp]['added_on']]=array_merge($pArray[$keyp],$pArray2[$keyp]);
        }
      }
      krsort($result);
      $finalResult=[];
      foreach ($result as $finalKey => $finalValue){
        $finalResult[]=$finalValue;
      }

//        print_r($finalResult);

//      exit();

      $aList[JSON_TAG_RESULT] = $finalResult;
//      $aList[JSON_TAG_RECORDS] = $row;
      $aList[JSON_TAG_STATUS] = 0;

    } catch (Exception $e) {
//       print_r($e);
      $aList[JSON_TAG_STATUS] = 1;
    }
    return $aList;
  }   
    /*
         Function            : leadList(Request $request, Response $response)
         Brief               : Function to get the lead-list
         Details             : Function to get the lead-list
         Input param         : Nil
         Input/output param  : Array
         Return              : Returns array.
        */
    public function leadList(){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();


            $sQuery ="SELECT DISTINCT(a.p_id),p.p_name,a.added_on FROM answers as a".
                " JOIN products as p ON a.p_id=p.p_id WHERE a.is_deleted='0' ORDER BY a.added_on DESC LIMIT 5";
            $db->query($sQuery);
            $leadlist1 = $db->resultSet();

            $sQuery ="SELECT DISTINCT(a.p_id),p.p_name,a.added_on,a.score FROM answers as a".
                " JOIN products as p ON a.p_id=p.p_id WHERE a.is_deleted='0' AND a.score <> 'null' ORDER BY a.score ASC LIMIT 5";
            $db->query($sQuery);
            $leadlist2 = $db->resultSet();

            $currentDate= date('Y-m-d H:i:s');
            $prevDate= date('Y-m-d', strtotime('-7 days'));
            $prevDate= $prevDate." 00:00:00";
//      print_r($prevDate);

            $arrayNew =[];
            $arrayNew1 =[];

            foreach ($leadlist1  as $key11 => $value11){
                if(($currentDate > $value11['added_on']) &&($prevDate < $value11['added_on']) ){
                    $arrayNew[$key11]=$value11;
                    $arrayNew[$key11]['flag']='1';
//          print_r($value11);
//          exit();
                }else{
                    $arrayNew[$key11]=$value11;
                    $arrayNew[$key11]['flag']='0';
                }
            }

            foreach ($leadlist2  as $key21 => $value21){
                if(($currentDate > $value21['added_on']) &&($prevDate < $value21['added_on']) ){
                    $arrayNew1[$key21]=$value21;
                    $arrayNew1[$key21]['flag']='1';
//          print_r($value11);
//          exit();
                }else{
                    $arrayNew1[$key21]=$value21;
                    $arrayNew1[$key21]['flag']='0';
                }
            }

            $leadArray = [];
            $leadArray['time_based']=$arrayNew;
            $leadArray['score_based']=$arrayNew1;


//      print_r($leadlist1);
//      print_r($leadlist2);
//      exit();
//      $pArray=[];
//      foreach ($plist  as $key1 => $value1){
//        $pArray[$value1['p_id']] = $value1;
//      }
//      exit();

//      foreach ($plist as $Pkey => $pvalue){
//        $sQuery ="SELECT a.p_id,u.fname,u.lname,a.score,a.flag,a.added_on FROM answers as a".
//            " JOIN users as u ON a.user_id=u.user_id WHERE a.p_id =:p_id AND a.is_deleted='0' ORDER BY a.added_on DESC";
//        $db->query($sQuery);
//        $db->bind(":p_id", $pvalue['p_id']);
//        $Rlist[] = $db->resultSet();
//      }
////print_r($pArray);
//
//      $pArray2=[];
//
//      foreach ($Rlist  as $key2 => $value2) {
//        $pArray2[$value2[0]['p_id']] = $value2[0];
//      }
//      $result=[];
//      foreach ($pArray  as $keyp => $valuep){
//        if(array_key_exists($keyp,$pArray2)){
//          $result[$pArray2[$keyp]['added_on']]=array_merge($pArray[$keyp],$pArray2[$keyp]);
//        }
//      }
//      krsort($result);
//      $finalResult=[];
//      foreach ($result as $finalKey => $finalValue){
//        $finalResult[]=$finalValue;
//      }

//        print_r($finalResult);

//      exit();

            $aList[JSON_TAG_RESULT] = $leadArray;
//      $aList[JSON_TAG_RECORDS] = $row;
            $aList[JSON_TAG_STATUS] = 0;

        } catch (Exception $e) {
//       print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }
    /*
        Function            : getUser(Request $request, Response $response)
        Brief               : Function to get user
        Details             : Function to get user
        Input param         : Nil
        Input/output param  : Array
        Return              : Returns array.
       */
    public function getUser($id){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $id['id'];

            if (empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $sQuery ="SELECT user_id,fname, lname, role, Date(updated_on)as added FROM `users` ".
                "WHERE is_deleted = 0 AND user_id = :user_id";
            $db->query($sQuery);
            $db->bind(":user_id", $userId);
            $userInfo = $db->single();
//      print_r($userInfo);

            if(!empty($userInfo)){
                $aList[JSON_TAG_RESULT] = $userInfo;
                $aList[JSON_TAG_STATUS] = 0;
            }else{
                $aList[JSON_TAG_CUSTOM_MSG] = "Data not found";
                $aList[JSON_TAG_STATUS] = 3;
            }


            return $aList;


//          print_r();




        } catch (Exception $e) {
//           print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }
    /*
          Function            : productScore(Request $request, Response $response)
          Brief               : Function to get the product Score
          Details             : Function to get the product Score
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */
    public function productScore($inData){

        try{

            $genMethod      = new GeneralMethod();
            $db             = new ConnectionManager();
            $userId         = $inData[JSON_TAG_USER_ID];
            $p_id           = $inData[JSON_TAG_PRODUCT_ID];

            if (empty($p_id) || empty($userId ) ) {
                $aList[JSON_TAG_CUSTOM_MSG] = "data cannot be empty";
                $aList[JSON_TAG_STATUS]     = 3;
                return $aList;
            }

            $rowUser = $this->checkUserId($db, $userId);
            if (empty($rowUser)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "User_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

            $rowProd = $this->productId($db, $p_id);
            if (empty($rowProd)) {
                $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
                $aList[JSON_TAG_STATUS] = 3;
                return $aList;
            }

          $sQuery ="SELECT a.p_id,u.fname,u.user_id,u.lname,u.role,u.email,a.score,a.flag,DATE (a.added_on) as added_on FROM ".
              "answers as a JOIN users as u ON a.user_id=u.user_id WHERE a.p_id =:p_id AND a.is_deleted='0' AND a.user_id=:user_id";
          $db->query($sQuery);
          $db->bind(":p_id", $p_id);
          $db->bind(":user_id", $userId);
          $prodDetail = $db->single();
          $prodDetail['names'] = $prodDetail['fname'].' '.$prodDetail['lname'];
          unset($prodDetail['fname']);
          unset($prodDetail['lname']);

          $sQuery = "SELECT field, question FROM `questions` WHERE is_deleted = 0";
            $db->query($sQuery);
            $queField = $db->resultSet();
            $queArray = [];

            foreach ($queField  as $keyQue => $valueQue){
                $queArray[$valueQue['field']] = $valueQue;
            }
//      print_r($queArray);



            $sQuery = "SELECT p_id FROM `products` WHERE is_deleted = 0";
            $db->query($sQuery);
            $productRow = $db->resultSet();
//
            $sQuery = "SELECT * FROM answers WHERE is_deleted = 0 AND p_id = :p_id AND user_id = :user_id";
            $db->query($sQuery);
            $db->bind(":p_id", $p_id);
            $db->bind(":user_id", $userId);
            $crtResp = $db->single();

            $notSelect = array('a_id','p_id','user_id','added_on','updated_on','is_deleted','flag','score');
            $currentresp = [];
            foreach ($crtResp as $kcr => $vcr){
                if(!in_array($kcr, $notSelect)){
//          print_r($vcr);
                    $currentresp[$kcr]= $vcr;
                }
            }
            foreach ($queArray as $kcr1 => $vcr1){
                if(array_key_exists($kcr1, $currentresp)){
//          print_r($vcr1);
                    $queArray[$kcr1]['answer']= $currentresp[$kcr1];
                }
            }

            $sQuery = "SELECT field, category FROM questions WHERE is_deleted = 0 ";
            $db->query($sQuery);
            $catRow = $db->resultSet();

            $array1 =[];
            foreach ($catRow as $kcat => $vcat){
                $array1[$vcat['field']]['category']= $vcat['category'];
            }

            foreach ($queArray as $kcr12 => $vcr12){
                if(array_key_exists($kcr12, $array1)){
//          print_r($vcr1);
                    $queArray[$kcr12]['category']= $array1[$kcr12]['category'];
                }
            }
//      print_r($queArray);

            $finalResult = [];
            foreach ($queArray as $finalk => $finalv){
                $finalResult[]=$finalv;
            }
          $finalResult['productDetails']= $prodDetail;






            $aList[JSON_TAG_RESULT] = $finalResult;
            $aList[JSON_TAG_STATUS] = 0;


        } catch (Exception $e) {
//      print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }


/*
          Function            : productUser(Request $request, Response $response)
          Brief               : Function to get the product Score
          Details             : Function to get the product Score
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */
  public function productUser($id){

    try{

      $genMethod      = new GeneralMethod();
      $db             = new ConnectionManager();
      $p_id         = $id['id'];





      $rowProd = $this->productId($db, $p_id);
      if (empty($rowProd)) {
        $aList[JSON_TAG_CUSTOM_MSG] = "product_id not exist";
        $aList[JSON_TAG_STATUS] = 3;
        return $aList;
      }

      $sQuery = "SELECT field, question FROM `questions` WHERE is_deleted = 0";
      $db->query($sQuery);
      $queField = $db->resultSet();
      $queArray = [];

      foreach ($queField  as $keyQue => $valueQue){
        $queArray[$valueQue['field']] = $valueQue;
      }
//      print_r($queArray);



      $sQuery = "SELECT p_id FROM `products` WHERE is_deleted = 0";
      $db->query($sQuery);
      $productRow = $db->resultSet();
//
      $sQuery = "SELECT * FROM answers WHERE is_deleted = 0 AND p_id = :p_id ";
      $db->query($sQuery);
      $db->bind(":p_id", $p_id);
      $crtResp = $db->resultSet();
      $Userlist = [];
       foreach ($crtResp as $keyusr => $valueusr){
         $sQuery = "SELECT user_id, fname, lname, email FROM `users` WHERE is_deleted = 0 AND user_id=:user_id";
         $db->query($sQuery);
         $db->bind(":user_id", $valueusr['user_id']);
         $productuser []= $db->single();
       }
      $userList = [];
      foreach ($productuser as $k => $v){
        $userList[$k]['user_id']= $v['user_id'];
        $userList[$k]['name'] = $v['fname'].' '.$v['lname'];
          $userList[$k]['email'] = $v['email'];
      }


      $notSelect = array('a_id','p_id','user_id','added_on','updated_on','is_deleted','flag','score');
      $currentresp = [];
      foreach ($crtResp as $kcr => $vcr){
        foreach ($vcr as $keycr => $valuecr){
          if(!in_array($keycr, $notSelect)){
//          print_r($vcr);
            $currentresp[$kcr][$keycr]= $valuecr;
          }
        }

      }
      $countArray= (count($currentresp));
      $sumAvg = [];
      foreach ($currentresp as $avgk => $avgv) {
        foreach ($avgv as $avgk1 => $avgv1) {
          $sumAvg[$avgk1] += $avgv1;
        }
      }
      foreach ($sumAvg as $avgk2 => $avgv2){
        $sumAvg[$avgk2] = $avgv2/$countArray;
      }
//      print_r($sumAvg);
//      exit();

      foreach ($queArray as $kcr1 => $vcr1){
        if(array_key_exists($kcr1, $sumAvg)){
//          print_r($vcr1);
          $queArray[$kcr1]['answer']= $sumAvg[$kcr1];
        }
      }

      $sQuery = "SELECT field, category FROM questions WHERE is_deleted = 0 ";
      $db->query($sQuery);
      $catRow = $db->resultSet();

      $array1 =[];
      foreach ($catRow as $kcat => $vcat){
        $array1[$vcat['category']][]= $vcat['field'];
      }
//      print_r($array1);

      $keyhold =[];
      $quehold=[];
      foreach ($array1 as $keyArray => $valArray){
        foreach ($valArray as $keyVA => $valVA){
          if(!empty($sumAvg[$valVA])){
            $tmp[]=$sumAvg[$valVA];
            $tmp1[$valVA]=$sumAvg[$valVA];
          }

//          print_r($tmp);
//          exit();
        }
        $keyhold[$keyArray]=$tmp;
        $quehold[$keyArray]=$tmp1;
        $tmp = [];
        $tmp1 = [];
      }
//print_r($keyhold);
//      print_r($quehold);

      $categoryPer = [];
      foreach ($keyhold as $khold => $vhold){
//        print_r(array_sum($vhold).'----------'.count($vhold));

        $categoryPer[$khold] = round( ((array_sum($vhold)/(5*count($vhold))) *100),2);
      }
      foreach ($categoryPer as $kNAN => $vNAN){
        if(is_nan($vNAN)){
          $categoryPer[$kNAN] = 0;
//          print_r('nooo');
        }
      }
//      print_r($categoryPer);
//-----------------
      $array12 =[];
      foreach ($catRow as $kcat => $vcat){
        $array12[$vcat['field']]['category']= $vcat['category'];
      }

      foreach ($queArray as $kcr12 => $vcr12){
        if(array_key_exists($kcr12, $array12)){
//          print_r($vcr1);
          $queArray[$kcr12]['category']= $array12[$kcr12]['category'];
        }
      }
//      print_r($queArray);

      $finalResult = [];
      foreach ($queArray as $finalk => $finalv){
        $finalResult[]=$finalv;
      }
      $finalResult['category'] = $categoryPer;
      $finalResult['userList'] = $userList;

      $aList[JSON_TAG_RESULT] = $finalResult;
      $aList[JSON_TAG_STATUS] = 0;


    } catch (Exception $e) {
//      print_r($e);
      $aList[JSON_TAG_STATUS] = 1;
    }
    return $aList;
  }
    /*
     Function            : adminLogin()
     Brief               : Function to admin login
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */
    public function adminLogin($inData){
        $db = new ConnectionManager();
        $generalMethod = new GeneralMethod();
        try {

            $email = $generalMethod->sanitizeString($inData[JSON_TAG_EMAIL]);

            $password = $generalMethod->sanitizeString($inData[JSON_TAG_PASSWORD]);
            if(empty($email)){
                $aList[JSON_TAG_STATUS] = 3;
                $aList[JSON_TAG_CUSTOM_MSG] ='no email id';
                return $aList;
            }

            if(empty($password)){
                $aList[JSON_TAG_STATUS] = 3;
                $aList[JSON_TAG_CUSTOM_MSG] ='password cannot be empty';
                return $aList;
            }

            $sQuery = " SELECT id FROM  login  WHERE  email =:email  AND password = MD5(:password) AND is_deleted =0  " ;
            //var_dump($sQuery);
            //exit();
            $db->query($sQuery);
            $db->bind(':email',$email);
            $db->bind(':password',$password);

            $row = $db->single();
            //var_dump($row);
            //exit();
            if(empty($row)){
                $aList[JSON_TAG_STATUS] = 3;
                $aList[JSON_TAG_CUSTOM_MSG]='invalid data';
            } else {
                $aList[JSON_TAG_STATUS] = 0;
                $aList[JSON_TAG_CUSTOM_MSG]='login successful';
            }

        } catch (Exception $e) {
            print_r($e);
            $aList[JSON_TAG_STATUS] = 1;
        }
        return $aList;
    }

//-------------------------------------------------------------------------------------------------------------------
    /*
        Function            : checkUserId($db, $user_id)
        Brief               : Function to validate user exists or not
        Details             : Function to validate user exists or not
        Input param         : $db, $email, $user_id
        Input/output param  : true/false
        Return              : bool.
       */
    function checkUserId($db, $user_id) {
        $sQuery = "SELECT user_id,email FROM users WHERE is_deleted = 0 AND user_id = :user_id";
        $db->query($sQuery);
        $db->bind(":user_id", $user_id);
        $row = $db->single();
        return $row;
    }

    /*
        Function            : productId($db, $p_id)
        Brief               : Function to validate product exists or not
        Details             : Function to validate product exists or not
        Input param         : $db, $email, $user_id
        Input/output param  : true/false
        Return              : bool.
       */
    function productId($db, $p_id) {
        $sQuery = "SELECT p_id FROM products WHERE is_deleted = 0 AND p_id = :p_id";
        $db->query($sQuery);
        $db->bind(":p_id", $p_id);
        $row = $db->single();
        return $row;
    }

    /*
        Function            : productName($db, $p_name)
        Brief               : Function to validate product exists or not
        Details             : Function to validate product exists or not
        Input param         : $db, $email, $user_id
        Input/output param  : true/false
        Return              : string.
       */
    function productName($db, $p_name, $version) {
        $sQuery = "SELECT p_id FROM products WHERE is_deleted = 0 AND p_name = :p_name AND version = :version";
        $db->query($sQuery);
        $db->bind(":p_name", $p_name);
        $db->bind(":version", $version);
        $row = $db->single();
        return $row;
    }

    /*
       Function            : getQuestionField($db, $q_id)
       Brief               : Function to fetch question field
       Details             : Function to fetch question field
       Input param         : $db, $q_id
       Input/output param  : true/false
       Return              : string.
      */
    function getQuestionField($db, $q_id) {
        $sQuery = "SELECT field FROM questions WHERE is_deleted = 0 AND id = :q_id";
        $db->query($sQuery);
        $db->bind(":q_id", $q_id);
        $row = $db->single();
        return $row;
    }
    /*
      Function            : getProductname($db, $q_id)
      Brief               : Function to fetch question field
      Details             : Function to fetch question field
      Input param         : $db, $q_id
      Input/output param  : true/false
      Return              : string.
     */
    function getProductname($db, $p_id) {
        $sQuery = "SELECT p_name ,version FROM products WHERE is_deleted = 0 AND p_id = :p_id";
        $db->query($sQuery);
        $db->bind(":p_id", $p_id);
        $row = $db->single();
        return $row;
    }




}
