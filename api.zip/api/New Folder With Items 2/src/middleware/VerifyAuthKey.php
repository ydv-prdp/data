<?php

// require_once 'library/vendor/slim/slim/Slim/Middleware.php';

class VerifyAuthKey {

	private $toSkip = ['app/user/login'];

	public function __invoke($request, $response, $next) {

		$headerAuth		= $request->getHeader('auth-key');
		$auth_key 		= explode(',', $headerAuth[0])[0];
		
		$headerUserId	= $request->getHeader('user-id');
		$enc_user_id 	= explode(',', $headerUserId[0])[0];

		$path 			= $request->getUri()->getPath();


		// skip if server is development, skip
		if (SERVER == "DEVELOPMENT") {
			return $next($request, $response);
		}

        // print_r($path);

		// skip for $toSkip
		if (in_array($path, $this->toSkip)) {
			return $next($request, $response);
		}
		

		$genMethod      = new GeneralMethod();
        $db             = new ConnectionManager();

        // decrypt user id
        $user_id 		= $genMethod->simple_crypt($enc_user_id, 'd');


        // check user exists or not
        $sQuery = "SELECT user_id, expires_on FROM users WHERE user_id = :user_id AND auth_key = :auth_key AND is_deleted = 0";
        $db->query($sQuery);
        $db->bind(":user_id", $user_id);
        $db->bind(":auth_key", $auth_key);
        $row = $db->single();

        // if no data found, return error 401 unauthorized
        if (empty($row)) {
        	return $response->withStatus(ERRCODE_UNAUTHORIZED)
		        ->withHeader('Content-Type', JSON_TAG_CONTENT_JSON)
		        ->write(json_encode(array(JSON_TAG_STATUS => JSON_TAG_ERROR,
                    JSON_TAG_DESC => ERROR_AUTH_KEY)));
        }


        // before performing any operation, check user's expires_on date.
        if ($row['expires_on'] < date(JSON_TAG_DATE_FORMAT)) {
        	return $response->withStatus(ERRCODE_UNAUTHORIZED)
		        ->withHeader('Content-Type', JSON_TAG_CONTENT_JSON)
		        ->write(json_encode(array(JSON_TAG_STATUS => JSON_TAG_ERROR,
                    JSON_TAG_DESC => ERROR_SESSION_EXPIRED)));
        }

        // perform API operation
        $response = $next($request, $response);


        // before returning response, update user's expires_on date
        $sQuery = "UPDATE users SET expires_on = TIMESTAMPADD(DAY, 15, NOW()) WHERE user_id =:user_id";
        $db->query($sQuery);
        $db->bind(":user_id", $user_id);
        $row = $db->execute();

        return $response;
    }
}
