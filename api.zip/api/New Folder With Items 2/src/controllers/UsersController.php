<?php
/*
  File name                   : UsersController.php 
  Description                 : Controller class for user related activities
 */

// namespace Controllers;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;


class UsersController {
     

    /*
      Function            : quest(Request $request, Response $response)
      Brief               : Function to get questions
      Details             : Function to get questions
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */    

    public function quest(Request $request, Response $response, $id) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->quest($id);
        return $genMethod->generateResult($response, $result);
    }



   ///feedback
   
    public function feedback(Request $request, Response $response){
        
        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_COMMENT, $inData)
        ) {

            $result = $usersManager->feedback($inData);
     
        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
   }
    /*
      Function            : answer(Request $request, Response $response)
      Brief               : Function to store the answer
      Details             : Function to store the answer
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */

    public function answer(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_PRODUCT_ID, $inData)
            && array_key_exists(JSON_TAG_QUESTION_ID, $inData)
            && array_key_exists(JSON_TAG_ANSWER, $inData)
            && array_key_exists(JSON_TAG_USER_ID, $inData)
            ) {

            $result = $usersManager->answerNew($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

    /*
      Function            : product(Request $request, Response $response)
      Brief               : Function to store the product-deatils
      Details             : Function to store the product-deatils
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */

    public function product(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
//            && array_key_exists(JSON_TAG_USER_ID, $inData)
            && array_key_exists(JSON_TAG_PRODUCT_NAME, $inData)
            && array_key_exists(JSON_TAG_VERSION, $inData)
        ) {

            $result = $usersManager->product($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }
    /*
      Function            : getProd(Request $request, Response $response)
      Brief               : Function to get products
      Details             : Function to get products
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */

    public function getProd(Request $request, Response $response, $id) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->getProd($id);
        return $genMethod->generateResult($response, $result);
    }

    /*
     Function            : user(Request $request, Response $response)
     Brief               : Function to store the user-deatils
     Details             : Function to store the user-deatils
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function user(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_USER_ID, $inData)
            && array_key_exists(JSON_TAG_FNAME, $inData)
            && array_key_exists(JSON_TAG_LNAME, $inData)
            && array_key_exists(JSON_TAG_ROLE, $inData)
        ) {

            $result = $usersManager->user($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

    /*
    Function            : addUser(Request $request, Response $response)
    Brief               : Function to add the user
    Details             : Function to add the user
    Input param         : Nil
    Input/output param  : Array
    Return              : Returns array.
   */

    public function addUser(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_EMAIL, $inData)
        ) {

            $result = $usersManager->addUser($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

    /*
   Function            : getAns(Request $request, Response $response)
   Brief               : Function to get the answer
   Details             : Function to get the answer
   Input param         : Nil
   Input/output param  : Array
   Return              : Returns array.
  */

    public function getAns(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
//            && array_key_exists(JSON_TAG_USER_ID, $inData)
            && array_key_exists(JSON_TAG_PRODUCT_ID, $inData)
            && array_key_exists(JSON_TAG_QUESTION_ID, $inData)
        ) {

            $result = $usersManager->getAns($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

    /*
          Function            : result(Request $request, Response $response)
          Brief               : Function to store the answer
          Details             : Function to store the answer
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */

    public function result(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);
         
        // $myObj->name = "John";
        // $myObj->age = 30;
        // $myObj->city = "New York";
        
        // $myJSON = json_encode($myObj);
        // return $myJSON ;
        if (is_array($inData)
            && array_key_exists(JSON_TAG_PRODUCT_ID, $inData)
            && array_key_exists(JSON_TAG_USER_ID, $inData)
        ) {
           
            $result = $usersManager->result($inData);
            
        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
      
    }
    /*
          Function            : interest(Request $request, Response $response)
          Brief               : Function to store the answer
          Details             : Function to store the answer
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */

    public function interest(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_PRODUCT_ID, $inData)
            && array_key_exists(JSON_TAG_USER_ID, $inData)
        ) {

            $result = $usersManager->interest($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

    /*-------------------dashboard-------------------------------------------*/
    /*
    Function            : response(Request $request, Response $response)
    Brief               : Function to get the response-deatils
     Details             : Function to get the response-deatils
    Input param         : Nil
    Input/output param  : Array
    Return              : Returns array.
   */

    public function response(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_INDEX, $inData)

        ) {

            $aList = $usersManager->response($inData);

        } else {
            return $genMethod->paramMissing($response);
        }

        return $genMethod->generateResult($response, $aList);
    }

    /*
     Function            : pieGraph(Request $request, Response $response)
     Brief               : Function to get the response-deatils
     Details             : Function to get the response-deatils
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function pieGraph(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->pieGraph();
        return $genMethod->generateResult($response, $result);
    }

    /*
     Function            : productList(Request $request, Response $response)
     Brief               : Function to get the product-deatils
     Details             : Function to get the product-deatils
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function productList(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->productList();
        return $genMethod->generateResult($response, $result);
    }
    /*
     Function            : leadList(Request $request, Response $response)
     Brief               : Function to get the lead-list
     Details             : Function to get the lead-list
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function leadList(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->leadList();
        return $genMethod->generateResult($response, $result);
    }

    /*
      Function            : getUser(Request $request, Response $response)
      Brief               : Function to get user
      Details             : Function to get user
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */

    public function getUser(Request $request, Response $response, $id) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->getUser($id);
        return $genMethod->generateResult($response, $result);
    }

    /*
      Function            : allQuestions(Request $request, Response $response)
      Brief               : Function to get all questions
      Details             : Function to get all questions
      Input param         : Nil
      Input/output param  : Array
      Return              : Returns array.
     */

    public function allQuestions(Request $request, Response $response, $id) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->allQuestions();
        return $genMethod->generateResult($response, $result);
    }
    /*
          Function            : productScore(Request $request, Response $response)
          Brief               : Function to get the product Score
          Details             : Function to get the product Score
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */

    public function productScore(Request $request, Response $response) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);

        if (is_array($inData)
            && array_key_exists(JSON_TAG_PRODUCT_ID, $inData)
            && array_key_exists(JSON_TAG_USER_ID, $inData)
        ) {

            $result = $usersManager->productScore($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }
    /*
          Function            : productUser(Request $request, Response $response)
          Brief               : Function to get products users list
          Details             : Function to get products users list
          Input param         : Nil
          Input/output param  : Array
          Return              : Returns array.
         */

    public function productUser(Request $request, Response $response, $id) {

        $genMethod      = new GeneralMethod();
        $usersManager   = new UsersManager();


        $result = $usersManager->productUser($id);
        return $genMethod->generateResult($response, $result);
    }
    /*
     Function            : adminLogin()
     Brief               : Function to admin login
     Input param         : Nil
     Input/output param  : Array
     Return              : Returns array.
    */

    public function adminLogin(Request $request, Response $response)
    {
        $genMethod = new GeneralMethod();
        $usersManager   = new UsersManager();

        $bodyData       = $request->getBody();
        $inData         = json_decode($bodyData, true);


        if (is_array($inData) && array_key_exists(JSON_TAG_EMAIL, $inData)
            && array_key_exists(JSON_TAG_PASSWORD, $inData)
        ){

            $result = $usersManager->adminLogin($inData);

        } else {
            return $genMethod->paramMissing($response);
        }
        return $genMethod->generateResult($response, $result);
    }

}
   
?>
