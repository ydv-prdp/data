<?php
/*
  Module                      : NA
  File name                   : messages.php
  Description                 : Contains debug descriptions retured in the error JSON.
 */

//******************  API MESSAGE ********************
define("INSUFFICIENT_PARAM", "Required params missing/incocrrect(Bad request)");

define("SERVER_EXCEPTION", "Server Exception");

define("MANDATORY_FIELD_REQUIRED", "Mandatory Field Required");

define("ERROR_PERMISSION_DENIED","User Permission Denied");

define("ERROR_DEFAULT","Something went wrong");

define("ERROR_AUTH_KEY","Invalid Auth Key");

define("ERROR_SESSION_EXPIRED","Session Expired, Login Again");

?>