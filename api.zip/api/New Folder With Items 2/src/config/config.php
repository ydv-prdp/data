<?php
//To supress the errors
error_reporting(1);
ini_set('display_errors', 1);
//error_reporting(E_ALL);
/*
  Module                      : NA
  File name                   : config.php
  Description                 : Contains configuration settings used in the project codes.
 */
/*********Credentials*********/
define("DBTYPE","mysql");
//define("SERVER", "PRODUCTION");
 define("SERVER", "DEVELOPMENT");

define("TIMEZONE", "UTC");


// to encrypt or decrypt, defined in GeneralMethod.php
define("ENC_SECRET_KEY", "#$%&1234");
define("ENC_SECRET_IV", "987#$@@!");
//Sendgrid API KEY /vinayct accnt
define("SENDGRID_APIKEY","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");

ini_set('max_execution_time', 0); 
date_default_timezone_set(TIMEZONE);
?>
