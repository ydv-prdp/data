<?php
/*
  Module                      : Json Tag Name
  File name                   : jsontags.php
  Description                 : Contains JSON tags used in the project codes.
 */
//************************GENERAL TAGS*******************************

define("JSON_TAG_CODE", 		"code");
define("JSON_TAG_STATUS_CODE", 	"status_code");
define("JSON_TAG_DESC", 		"description");
define("JSON_TAG_CONTENT_JSON", "application/json");
define("JSON_TAG_RECORDS",		"records");
define("JSON_TAG_STATUS", 		"status");
define("JSON_TAG_SUCCESS", 		"success");
define("JSON_TAG_FAIL", 		"fail");
define("JSON_TAG_ERROR", 		"error");
define("JSON_TAG_RESULT", 		"result");
define("JSON_TAG_CUSTOM_MSG",	"custom_message");
define("ERROR_DEFAULT",			"Something went wrong");
define("JSON_TAG_DATE_FORMAT", 	"Y-m-d H:i:s");

// users data
define("JSON_TAG_USER_ID", 		"user_id");
define("JSON_TAG_NAME",			"name");
define("JSON_TAG_EMAIL",		"email");
define("JSON_TAG_PRODUCT_ID",	"product_id");
define("JSON_TAG_QUESTION_ID",	"question_id");
define("JSON_TAG_ANSWER",	    "answer");
define("JSON_TAG_PRODUCT_NAME",	"product_name");
define("JSON_TAG_VERSION",		"version");
define("JSON_TAG_TIMEZONE",		"timezone");
define("JSON_TAG_FNAME",	    "first_name");
define("JSON_TAG_LNAME",		"last_name");
define("JSON_TAG_ROLE",			"role");
define("JSON_TAG_PASSWORD",			"password");



// feeds data
define("JSON_TAG_TAGS", 		"tags");
define("JSON_TAG_INDEX", 		"index");
define("JSON_TAG_ITEM_COUNT", 	"item_count");
define("JSON_TAG_FEED_ID", 		"feed_id");
define("JSON_TAG_COMMENT", 		"comment");
define("JSON_TAG_HELPFUL", 		"helpful");

// for user's profile
define("JSON_TAG_TAB", 			"tab");
?>