<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$email_id = $_POST['email_id'];
$time1 = $_POST['testDate'];
echo "<script>console.log('check') </script>";


require_once 'src/config/config.php';
require_once 'src/config/connect.php';
require_once 'src/utils/GeneralMethod.php';
require_once 'src/utils/ConnectionManager.php';
require_once __DIR__ . '/vendor/autoload.php';



$genMethod      = new GeneralMethod();
$db             = new ConnectionManager();

    $time = date('Y-m-d\TH:i:sO');
    $message="<html xmlns='https://www.w3.org/1999/xhtml' xmlns:v='urn:schemas-microsoft-com:vml'
    xmlns:o='urn:schemas-microsoft-com:office:office'>

<head>
    <!--[if gte mso 9]><xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG/>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
    </xml><![endif]-->
    <title>DMI Email</title>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0 '>
    <meta name='format-detection' content='telephone=no'>
    <!--[if !mso]><!-->
    <link href='https://db.onlinewebfonts.com/c/0e6de1ec911a2e267ff136bbdd384a44?family=Helvetica+Neue' rel='stylesheet'
        type='text/css' />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet'>
    <!--<![endif]-->
    <style type='text/css'>
    <style type='text/css'>
    body {
  margin: 0 !important;
  padding: 0 !important;
  -webkit-text-size-adjust: 100% !important;
  -ms-text-size-adjust: 100% !important;
  -webkit-font-smoothing: antialiased !important;
}
a {

    text-decoration: none;

}
  </style>
    </style>
</head>
<body width='680' style='width:680px;margin:auto;'>
    <div class='body-wrapper' style='width: 680px;background-color: #fff;'>
    <a href='mailto:".$email_id."' style='color:#4F5A68;text-decoration:none;display:inline-block;'><span style='color:#4F5A68;text-decoration:none;'>  ".$email_id."   wants to get in touch with XD LAB ,Time Stamp- ".$time1."</span></a>  
    </div>
</body>

</html>";

    $genMethod->sendMails('experiencedesign.ct@siemens.com','Siemens-DMI :Get in touch', $message, $time, false, true);
    $aList[JSON_TAG_STATUS] = 0;




?>
