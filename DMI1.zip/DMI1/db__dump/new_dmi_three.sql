-- MariaDB dump 10.17  Distrib 10.4.11-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: new_dmi_three
-- ------------------------------------------------------
-- Server version	10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answers` (
  `a_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL COMMENT 'Product id',
  `user_id` int(11) NOT NULL COMMENT 'User id',
  `q1` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q2` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q3` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q4` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q5` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q6` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q7` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q8` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q9` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q10` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q11` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q12` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q13` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q14` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q15` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q16` enum('1','2','3','4','5','0') DEFAULT NULL,
  `score` float DEFAULT NULL,
  `flag` enum('0','1') NOT NULL DEFAULT '0',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answers`
--

LOCK TABLES `answers` WRITE;
/*!40000 ALTER TABLE `answers` DISABLE KEYS */;
INSERT INTO `answers` VALUES (213,167,305,'5','5','5','5','5','5','5','5','5','5','5','5','5','5','5',NULL,100,'0','2021-02-22 14:34:53','2021-02-22 14:36:47',0),(214,168,306,'3','3','3','3','3','3','3','3','3','3','3','3','3','3','3',NULL,60,'0','2021-02-22 14:37:15','2021-02-22 14:38:07',0),(215,169,307,'2','2','2','2','2','2','2','2','2','2','2','2','2','2','2',NULL,40,'0','2021-02-22 14:38:44','2021-02-22 14:39:32',0),(216,170,308,'1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',NULL,20,'0','2021-02-22 14:40:11','2021-02-22 14:41:04',0),(217,171,309,'5','2','3','1','5','3','2','5','1','5','1','3','2','5','1',NULL,58.67,'0','2021-02-22 14:41:40','2021-02-22 14:42:31',0),(218,172,310,'3','1','5','3','1','5','1','3','5','1','5','3','1','3','5',NULL,60,'0','2021-02-22 14:45:57','2021-02-22 14:46:45',0),(219,173,311,'5','3','5','2','3','5','1','3','5','3','2','5','2','3','2',NULL,65.33,'0','2021-02-22 15:29:48','2021-02-22 15:30:33',0),(220,174,312,'2','5','2','5','1','3','5','1','3','1','5','2','3','2','3',NULL,57.33,'0','2021-02-22 15:32:09','2021-02-22 15:32:51',0),(221,175,313,'5','5','5','5','5','5','5','5','5','5','5','5','5','5','5',NULL,100,'0','2021-02-23 04:51:06','2021-02-23 04:51:55',0),(222,179,317,'5','5','5','5','5','5','5','5','5','5','5','5','5','5','5',NULL,100,'0','2021-02-24 07:03:41','2021-02-24 07:04:51',0),(223,180,318,'5','5','5','5','5','5','5','5','5','5','5','5','5','5','5',NULL,100,'0','2021-02-24 07:23:11','2021-02-24 07:27:33',0),(224,181,319,'5','5','5','3','2','3','5','2','5','3','1','2','1','3','3',NULL,64,'0','2021-02-24 07:31:13','2021-02-24 07:52:16',0),(225,182,320,'5','2','2','3','5','1','3','5','1','5','3','5','2','1','2',NULL,60,'0','2021-02-24 07:53:22','2021-02-24 07:54:21',0),(226,183,321,'2','5','3','5','3','2','5','2','5','3','5','5','5','5','5',NULL,80,'0','2021-02-24 08:41:09','2021-02-24 08:41:55',0),(227,184,322,'2','3','2','1','5','3','2','5','3','2','5','2','3','1','2',NULL,54.67,'0','2021-02-24 08:51:49','2021-02-24 08:52:34',0),(228,185,323,'5','3','2','5','2','5','2','3','5','1','5','2','5','5','1',NULL,68,'0','2021-02-24 09:44:09','2021-02-24 09:45:04',0),(229,186,324,'5','1','3','2','5','1','5','3','5','2','5','2','5','2','5',NULL,68,'0','2021-02-24 09:54:30','2021-02-24 09:55:12',0),(230,187,325,'5','5','3','5','5','2','5','1','2','3','5','2','5','1','5',NULL,72,'0','2021-02-24 10:02:15','2021-02-24 10:02:58',0),(231,188,326,'5','3','2','1','5','3','5','2','1','3','5','1','2','3','5',NULL,61.33,'0','2021-02-24 10:07:59','2021-02-24 10:08:38',0),(232,189,327,'5','2','3','1','1','5','3','2','5','1','5','1','5','3','2',NULL,58.67,'0','2021-02-24 10:11:09','2021-02-24 10:12:25',0),(233,190,328,'5','3','2','1','3','2','5','1','3','1','5','1','3','5','1',NULL,54.67,'0','2021-02-24 10:24:45','2021-02-24 10:25:22',0),(234,191,329,'1','2','3','5','1','2','5','1','5','3','5','1','5','3','5',NULL,62.67,'0','2021-02-24 10:34:25','2021-02-24 10:35:04',0),(235,192,330,'5','3','5','1','5','1','5','1','5','1','2','3','5','1','5',NULL,64,'0','2021-02-24 10:45:28','2021-02-24 10:46:17',0),(236,193,331,'5','5','2','1','3','1','3','2','3','5','2','3','3','5','2',NULL,60,'0','2021-02-24 11:02:49','2021-02-24 11:03:41',0),(237,194,332,'5','1','3','5','1','3','5','1','2','3','2','3','1','5','2',NULL,56,'0','2021-02-24 11:05:57','2021-02-24 11:06:53',0),(238,195,333,'5','3','5','1','5','3','1','3','5','1','3','1','5','1','3',NULL,60,'0','2021-02-24 11:11:25','2021-02-24 11:12:05',0),(239,196,334,'5','2','3','5','3','1','5','3','2','5','1','5','3','2','3',NULL,64,'0','2021-02-24 11:48:00','2021-02-24 11:48:44',0),(240,197,335,'5','3','2','5','3','2','5','5','3','2','5','2','3','1','5',NULL,68,'0','2021-02-24 14:03:27','2021-02-24 14:04:23',0),(241,198,336,'2','1','3','1','5','1','5','2','3','1','5','1','5','1','5',NULL,54.67,'0','2021-02-24 14:09:58','2021-02-24 14:10:42',0),(242,199,337,'3','5','1','3','5','1','5','1','3','2','5','1','5','3','5',NULL,64,'0','2021-02-24 14:19:28','2021-02-24 14:41:45',0),(243,200,338,'5','3','5','5','3','5','2','5','1','5','1','5','2','5','2',NULL,72,'0','2021-02-24 14:42:39','2021-02-24 14:43:20',0);
/*!40000 ALTER TABLE `answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `p_id` int(11) NOT NULL COMMENT 'Product id',
  `user_id` int(11) NOT NULL COMMENT 'User id',
  `p_name` text NOT NULL COMMENT 'Product name',
  `comment` text NOT NULL COMMENT 'feedback comment',
  `helpful` text NOT NULL COMMENT 'helpful'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'admin@siemens.com','81dc9bdb52d04dc20036dbd8313ed055',NULL,NULL,0),(2,'varshini.s@cumulations.com','81dc9bdb52d04dc20036dbd8313ed055','2018-10-24 13:47:38','2018-10-24 13:47:38',0),(3,'karthik@cumulations.com','81dc9bdb52d04dc20036dbd8313ed055','2018-10-24 13:50:05','2018-10-24 13:50:05',0),(4,'arnab.khound@siemens.com','9091120e824ca1442fbb6c987caaed60','2019-09-18 09:50:22','2019-09-18 09:50:22',0),(5,'abhilasha@siemens.com','17c018ba028e090a4e216b7119ad7e03','2019-09-18 09:52:24','2019-09-18 09:52:24',0),(6,'vishal.hemanth@siemens.com','98eddd38f8dc7b29f36c9c191d22903b','2019-09-18 09:52:24','2019-09-18 09:52:24',0),(7,'arun.thangaraj@siemens.com','85b90242e83cf11ef35ebd0ba736e696','2019-09-18 09:52:24','2019-09-18 09:52:24',0);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Product Id',
  `p_name` text NOT NULL COMMENT 'Product name',
  `version` varchar(50) NOT NULL COMMENT 'Product version',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`p_id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (167,'7213987','1','2021-02-22 14:34:45','2021-02-22 14:34:45',0),(168,'80980','1','2021-02-22 14:37:10','2021-02-22 14:37:10',0),(169,'0-9-eq','1','2021-02-22 14:38:39','2021-02-22 14:38:39',0),(170,'700','1','2021-02-22 14:40:04','2021-02-22 14:40:04',0),(171,'7309812903812','1','2021-02-22 14:41:34','2021-02-22 14:41:34',0),(172,'4723420938','1','2021-02-22 14:45:53','2021-02-22 14:45:53',0),(173,'730459834098','1','2021-02-22 15:29:43','2021-02-22 15:29:43',0),(174,'80958','1','2021-02-22 15:31:56','2021-02-22 15:31:56',0),(175,'789798','1','2021-02-23 04:50:48','2021-02-23 04:50:48',0),(176,'75304990','1','2021-02-24 06:21:52','2021-02-24 06:21:52',0),(177,'summer','1','2021-02-24 06:40:26','2021-02-24 06:40:26',0),(178,'8059820','1','2021-02-24 06:55:24','2021-02-24 06:55:24',0),(179,'ini','1','2021-02-24 07:03:33','2021-02-24 07:03:33',0),(180,'47982743','1','2021-02-24 07:23:07','2021-02-24 07:23:07',0),(181,'27430980','1','2021-02-24 07:31:09','2021-02-24 07:31:09',0),(182,'34598','1','2021-02-24 07:53:00','2021-02-24 07:53:00',0),(183,'23423','1','2021-02-24 08:41:01','2021-02-24 08:41:01',0),(184,'8409850','1','2021-02-24 08:51:37','2021-02-24 08:51:37',0),(185,'329427','1','2021-02-24 09:43:54','2021-02-24 09:43:54',0),(186,'34580','1','2021-02-24 09:54:18','2021-02-24 09:54:18',0),(187,'7098','1','2021-02-24 10:02:05','2021-02-24 10:02:05',0),(188,'480393','1','2021-02-24 10:07:46','2021-02-24 10:07:46',0),(189,'5430985','1','2021-02-24 10:10:57','2021-02-24 10:10:57',0),(190,'435098','1','2021-02-24 10:24:32','2021-02-24 10:24:32',0),(191,'2392','1','2021-02-24 10:34:12','2021-02-24 10:34:12',0),(192,'08','1','2021-02-24 10:45:23','2021-02-24 10:45:23',0),(193,'4378','1','2021-02-24 11:02:30','2021-02-24 11:02:30',0),(194,'234897','1','2021-02-24 11:05:46','2021-02-24 11:05:46',0),(195,'423987','1','2021-02-24 11:10:59','2021-02-24 11:10:59',0),(196,'sun','1','2021-02-24 11:47:41','2021-02-24 11:47:41',0),(197,'47239','1','2021-02-24 14:03:22','2021-02-24 14:03:22',0),(198,'23809','1','2021-02-24 14:09:53','2021-02-24 14:09:53',0),(199,'453098','1','2021-02-24 14:19:22','2021-02-24 14:19:22',0),(200,'835098','1','2021-02-24 14:42:36','2021-02-24 14:42:36',0);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `response_options` text NOT NULL,
  `response_emoji` text NOT NULL,
  `response_values` text NOT NULL,
  `category` int(11) NOT NULL COMMENT 'Group to which this question belongs to',
  `field` varchar(25) NOT NULL COMMENT 'field name for questions',
  `added_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,'Are there enough efforts towards identifying and demonstrating the value of digitalization initiative?','Yes, the efforts are commendable$ Yes, it is satisfactory$ No, a lot more can be done$ No, there are no such efforts','image_1$image_2$image_3$image_4','5,3,2,1',3,'q15','2018-07-04 11:18:57','2018-07-04 11:18:57',0),(2,'Do you feel involved in the change plan and process?','Yes, I have been involved extensively in the process$ Yes, but the discussions are restricted to significant few $ Rarely I have felt included in the process $ No, I am not part of the process at all.','image_1$image_2$image_3$image_4','5,3,2,1',3,'q14','2018-07-04 11:18:31','2018-07-04 11:18:31',0),(3,'Do you feel there is room for mistakes while learning to adapt to the digitalization initiative?','I see support in overcoming the steep learning curve  $ I hope there will be enough time provided to learn and adapt $ I am afraid that I will be judged and discouraged for failure $ I am concerned, there will be consequences if I fail','image_1$image_2$image_3$image_4','5,3,2,1',3,'q13','2018-07-04 11:17:00','2018-07-04 11:17:00',0),(4,'Do you see this change as a significant contributor towards the achievement of your career goal?','Objectives are compatible and would contribute to my achievement  $ I am in a safe zone with lesser risk $ Objectives are misaligned and mismatch my personal goals  $ It poses a threat and can have adverse effects ','image_1$image_2$image_3$image_4','5,3,2,1',3,'q12','2018-06-29 10:52:23','2018-06-29 10:52:23',0),(5,'How secure would you feel about your work after the change is introduced?','The work environment is conducive for me to adapt $ I see this change as an opportunity to grow  $ It challenges my comfort zone $ It would be a challenging phase breeding insecurity','image_1$image_2$image_3$image_4','5,3,2,1',3,'q11','2018-06-29 13:22:39','2018-06-30 09:18:35',0),(6,'At what level do you see yourself in adapting the required digitalization change?','I have the required skills and knowledge to adapt to the change $ I would require advanced skills and trainings to adapt to the change $ I know the basics $ I will have to start from scratch','image_1$image_2$image_3$image_4','5,3,2,1',2,'q10','2018-06-29 11:23:40','2018-06-29 11:23:40',0),(7,'How often do you see the team under pressure?','Efficient management of time and work tackles the pressure $ Deliverables are somehow managed on time $ Quite often team overshoots the delivery time $ Overly burdened and under pressure is the new normal for my team','image_1$image_2$image_3$image_4','5,3,2,1',2,'q9','2018-06-29 10:52:23','2018-06-29 10:52:23',0),(8,'Is the change meaningful to you?','It is thoughtfully planned and meaningful to me $ Proper implementation can improve it’s worth $ I do not understand it properly, but it has got some value in it $ It is completely irrelevant','image_1$image_2$image_3$image_4','5,3,2,1',2,'q8','2018-07-04 11:17:00','2018-07-04 11:17:00',0),(9,'Are the relevant resources available and accessible to you for an effective adoption of the Digitalization Initiatives?','Yes, adequate support of resources required would be easily accessible to me $ I can see the necessary efforts going on to make the resources available $ Resources would be available, but I am doubtful if it would be abundant and easily accessible. $ No, resource availability would be a problem','image_1$image_2$image_3$image_4','5,3,2,1',2,'q7','2018-07-04 11:18:00','2018-07-04 11:18:00',0),(10,'How are teams demonstrating the value of digitalization initiative?','Continuous and sustained engagement$ Periodical engagement with teams in terms of communicating the KPI results of the initiative$ Only initial engagement in terms of awareness creation$ Not much done in this direction','image_1$image_2$image_3$image_4','5,3,2,1',2,'q6','2018-07-04 11:19:13','2018-07-04 11:19:13',0),(11,'To what extent do you believe that your daily work pattern would change because of the digitalization initiative?','I foresee an optimized work pattern $ Adjust to the new work pattern would take time nevertheless manageable $ It would be hectic and worrisome to cope up with the new work pattern $ I feel the change is been forced upon us and will have drastic impact','image_1$image_2$image_3$image_4','5,3,2,1',1,'q5','2018-07-04 11:18:00','2018-07-04 11:18:00',0),(12,'Do you have a clear understanding of the digitalization initiative in your division/department?','I am convinced with the need and purpose of the initiative $ Even though I am not an expert, I have a fair idea $ I do understand the urgency but not sure if I understand the purpose clearly $ I don’t understand as to why it is even needed','image_1$image_2$image_3$image_4','5,3,2,1',1,'q4','2018-07-04 11:18:31','2018-07-04 11:18:31',0),(13,'Is the communication being clear and effective?','Yes, I can easily understand and relate to what is being conveyed$ Yes, I can understand but cannot relate to what is being conveyed $ No, a lot of jargons being used$ No, the communication of vision is very high level and makes no sense to me','image_1$image_2$image_3$image_4','5,3,2,1',1,'q3','2018-07-04 11:18:57','2018-07-04 11:18:57',0),(14,'Is there an innovation leader / driver in your organization for leveraging and extend the organization’s digital transformation?','Yes, we have a clear vision with sponsorship and plans to execute$ Yes, but only some teams are involved$ Yes, but the vision is not clear$ No','image_1$image_2$image_3$image_4','5,3,2,1',1,'q2','2018-07-23 05:54:53','2018-07-23 05:54:53',0),(15,'What level of support do the ecosystem (colleagues) provide to achieve the digitalization initiative goals?','I believe my colleagues will provide me adequate support $ It is difficult to reach out to the relevant personnel $ I am not sure if I will get adequate support $ I don’t see a support system at all','image_1$image_2$image_3$image_4','5,3,2,1',1,'q1','2018-06-28 12:09:50','2018-06-28 12:09:50',0);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `responses`
--

DROP TABLE IF EXISTS `responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q_id` varchar(25) DEFAULT NULL COMMENT 'Responses for which category it belongs to',
  `positive` text NOT NULL,
  `negative` text NOT NULL,
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responses`
--

LOCK TABLES `responses` WRITE;
/*!40000 ALTER TABLE `responses` DISABLE KEYS */;
INSERT INTO `responses` VALUES (1,'q1','information architecture','cluttered information','2018-07-24 22:08:55','2018-07-24 22:08:55',0),(2,'q1','display of relevant information','sorting of relevant information','2018-07-24 22:08:55','2018-07-24 22:08:55',0),(3,'q1','information organization','cluttered information','2018-07-24 22:12:17','2018-07-24 22:12:17',0),(4,'q2','perceived accuracy','feedback from the system','2018-07-24 22:12:17','2018-07-24 22:12:17',0),(5,'q2','prediction of relevant information','processing speed','2018-07-24 22:13:34','2018-07-24 22:13:34',0),(6,'q3','understandability','task assistance','2018-07-24 22:14:46','2018-07-24 22:14:46',0),(7,'q3','availability of relevant information','quality of help provided','2018-07-24 22:16:16','2018-07-24 22:16:16',0),(8,'q4','information hierarchy ','searching for relevant information','2018-07-24 22:18:23','2018-07-24 22:18:23',0),(9,'q4','easy navigation','searching for relevant information','2018-07-24 22:18:23','2018-07-24 22:18:23',0),(10,'q5','efficiency','reachability of reasonable level of usage or proficiency within a short period of time','2018-07-24 22:22:44','2018-07-24 22:22:44',0),(11,'q5','installation','ease of upgradation','2018-07-24 22:22:44','2018-07-24 22:22:44',0),(12,'q6','ease in memorising the steps for performing a task','effort required to remember and recall while performing a task','2018-07-24 22:24:01','2018-07-24 22:24:01',0),(13,'q6','minimal actions required to complete tasks','number of steps required to complete a task','2018-07-24 22:24:01','2018-07-24 22:24:01',0),(14,'q7','error prevention','appropriate feedback for errors','2018-07-24 22:08:55','2018-07-24 22:08:55',0),(15,'q7','error rectification','appropriate feedback for  errors','2018-07-24 22:08:55','2018-07-24 22:08:55',0),(16,'q8','visibility of application in current state','error visibility','2018-07-24 22:12:17','2018-07-24 22:12:17',0),(17,'q8','assuring accuracy','error visibility','2018-07-24 22:12:17','2018-07-24 22:12:17',0),(18,'q9','maintaining confidentiality','privacy and security','2018-07-24 22:13:34','2018-07-24 22:13:34',0),(19,'q9','maintaining data integrity','privacy and security','2018-07-24 22:14:46','2018-07-24 22:14:46',0),(20,'q10','minimal mental load while performing tasks','reducing conscious effort to work on the system','2018-07-24 22:16:16','2018-07-24 22:16:16',0),(21,'q11','establishing match between  mental model and conceptual model of the user','customization of components','2018-07-24 22:18:23','2018-07-24 22:18:23',0),(22,'q12','satisfaction of accomplishing any task','accessing information','2018-07-24 22:18:23','2018-07-24 22:18:23',0),(23,'q13','appropriateness of design','visual Clutter','2018-07-24 22:22:44','2018-07-24 22:22:44',0),(24,'q13','application color scheme','visual Clutter','2018-07-24 22:22:44','2018-07-24 22:22:44',0),(25,'q14','look and feel of the brand','appropriateness of the logo used','2018-07-24 22:24:01','2018-07-24 22:24:01',0),(26,'q15','consistency\r\n','spacing and typography used','2018-07-24 22:24:01','2018-07-24 22:24:01',0),(27,'q15','spacing and typography consistency\r\n','header hierarchy','2018-07-24 22:22:44','2018-07-24 22:22:44',0),(28,'q15','animation','presentation','2018-07-24 22:22:44','2018-07-24 22:22:44',0);
/*!40000 ALTER TABLE `responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL COMMENT 'Siemens email id',
  `fname` varchar(255) DEFAULT NULL COMMENT 'first name',
  `lname` varchar(255) DEFAULT NULL COMMENT 'last name',
  `role` varchar(255) DEFAULT NULL COMMENT 'Relationship with the project',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (305,'7897123@siemens.com','7897123@siemens','Com','customer','2021-02-22 14:34:41','2021-02-22 14:35:48',0),(306,'72397922@siemens.com','72397922@siemens','Com','customer','2021-02-22 14:37:05','2021-02-22 14:38:07',0),(307,'uup@siemens.com','Uup@siemens','Com','customer','2021-02-22 14:38:34','2021-02-22 14:39:32',0),(308,'68979@siemens.com','68979@siemens','Com','customer','2021-02-22 14:39:59','2021-02-22 14:41:04',0),(309,'78798@siemens.com','78798@siemens','Com','customer','2021-02-22 14:41:29','2021-02-22 14:42:32',0),(310,'742309809238@siemens.com','742309809238@siemens','Com','customer','2021-02-22 14:45:48','2021-02-22 14:46:45',0),(311,'423786239@siemens.com','423786239@siemens','Com','customer','2021-02-22 15:29:39','2021-02-22 15:30:35',0),(312,'4238723809@siemens.com','4238723809@siemens','Com','customer','2021-02-22 15:31:53','2021-02-22 15:32:51',0),(313,'437092384230@siemens.com','437092384230@siemens','Com','customer','2021-02-23 04:50:43','2021-02-23 04:51:55',0),(314,'3462378@siemens.com',NULL,NULL,NULL,'2021-02-24 06:21:26','2021-02-24 06:21:26',0),(315,'23748923@siemens.com',NULL,NULL,NULL,'2021-02-24 06:23:49','2021-02-24 06:23:49',0),(316,'749723@siemens.com',NULL,NULL,NULL,'2021-02-24 06:55:17','2021-02-24 06:55:17',0),(317,'723492093@siemens.com','723492093@siemens','Com','customer','2021-02-24 07:03:27','2021-02-24 07:04:51',0),(318,'462378468@siemens.com','462378468@siemens','Com','customer','2021-02-24 07:23:01','2021-02-24 07:24:01',0),(319,'432982930@siemens.com','432982930@siemens','Com','customer','2021-02-24 07:31:04','2021-02-24 07:31:58',0),(320,'1232@siemens.com','1232@siemens','Com','customer','2021-02-24 07:52:55','2021-02-24 07:54:22',0),(321,'42342@siemens.com','42342@siemens','Com','customer','2021-02-24 08:40:56','2021-02-24 08:41:55',0),(322,'688@siemens.com','688@siemens','Com','customer','2021-02-24 08:51:33','2021-02-24 08:52:35',0),(323,'64726483@siemens.com','64726483@siemens','Com','customer','2021-02-24 09:43:48','2021-02-24 09:45:05',0),(324,'438297492@siemens.com','438297492@siemens','Com','customer','2021-02-24 09:54:13','2021-02-24 09:55:13',0),(325,'742398@siemens.com','742398@siemens','Com','customer','2021-02-24 10:02:02','2021-02-24 10:02:58',0),(326,'74985@siemens.com','74985@siemens','Com','customer','2021-02-24 10:07:40','2021-02-24 10:08:38',0),(327,'8423098403@siemens.com','8423098403@siemens','Com','customer','2021-02-24 10:10:53','2021-02-24 10:12:25',0),(328,'749238@siemens.com','749238@siemens','Com','customer','2021-02-24 10:24:27','2021-02-24 10:25:23',0),(329,'27398@siemens.com','27398@siemens','Com','customer','2021-02-24 10:34:08','2021-02-24 10:35:04',0),(330,'379324@siemens.com','379324@siemens','Com','customer','2021-02-24 10:45:19','2021-02-24 10:46:18',0),(331,'47982374@siemens.com','47982374@siemens','Com','customer','2021-02-24 11:02:25','2021-02-24 11:03:41',0),(332,'4739888493@siemens.com','4739888493@siemens','Com','customer','2021-02-24 11:05:42','2021-02-24 11:06:54',0),(333,'42382@siemens.com','42382@siemens','Com','customer','2021-02-24 11:10:54','2021-02-24 11:12:06',0),(334,'32648273@siemens.com','32648273@siemens','Com','customer','2021-02-24 11:46:24','2021-02-24 11:48:44',0),(335,'6243873@siemens.com',NULL,NULL,NULL,'2021-02-24 14:03:18','2021-02-24 14:03:18',0),(336,'4723098@siemens.com','4723098@siemens','Com','customer','2021-02-24 14:09:48','2021-02-24 14:10:42',0),(337,'742393472@siemens.com','742393472@siemens','Com','customer','2021-02-24 14:19:18','2021-02-24 14:20:16',0),(338,'63428@siemens.com','63428@siemens','Com','customer','2021-02-24 14:42:31','2021-02-24 14:43:20',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-24 22:11:45
