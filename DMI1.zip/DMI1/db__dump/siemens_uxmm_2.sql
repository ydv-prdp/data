-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 01:39 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `siemens_uxmm_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `a_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL COMMENT 'Product id',
  `user_id` int(11) NOT NULL COMMENT 'User id',
  `q1` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q2` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q3` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q4` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q5` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q6` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q7` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q8` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q9` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q10` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q11` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q12` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q13` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q14` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q15` enum('1','2','3','4','5','0') DEFAULT NULL,
  `q16` enum('1','2','3','4','5','0') DEFAULT NULL,
  `score` float DEFAULT NULL,
  `flag` enum('0','1') NOT NULL DEFAULT '0',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--




-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`, `added_on`, `updated_on`, `is_deleted`) VALUES
(1, 'admin@siemens.com', '81dc9bdb52d04dc20036dbd8313ed055', NULL, NULL, 0),
(2, 'varshini.s@cumulations.com', '81dc9bdb52d04dc20036dbd8313ed055', '2018-10-24 13:47:38', '2018-10-24 13:47:38', 0),
(3, 'karthik@cumulations.com', '81dc9bdb52d04dc20036dbd8313ed055', '2018-10-24 13:50:05', '2018-10-24 13:50:05', 0),
(4, 'arnab.khound@siemens.com', '9091120e824ca1442fbb6c987caaed60', '2019-09-18 09:50:22', '2019-09-18 09:50:22', 0),
(5, 'abhilasha@siemens.com', '17c018ba028e090a4e216b7119ad7e03', '2019-09-18 09:52:24', '2019-09-18 09:52:24', 0),
(6, 'vishal.hemanth@siemens.com', '98eddd38f8dc7b29f36c9c191d22903b', '2019-09-18 09:52:24', '2019-09-18 09:52:24', 0),
(7, 'arun.thangaraj@siemens.com', '85b90242e83cf11ef35ebd0ba736e696', '2019-09-18 09:52:24', '2019-09-18 09:52:24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL COMMENT 'Product Id',
  `p_name` text NOT NULL COMMENT 'Product name',
  `version` varchar(50) NOT NULL COMMENT 'Product version',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--



-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `response_options` text NOT NULL,
  `response_emoji` text NOT NULL,
  `response_values` text NOT NULL,
  `category` int(11) NOT NULL COMMENT 'Group to which this question belongs to',
  `field` varchar(25) NOT NULL COMMENT 'field name for questions',
  `added_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `response_options`, `response_values`,`response_emoji`, `category`, `field`, `added_on`, `updated_on`, `is_deleted`) VALUES
(1, 'Can you associate the application with the Siemens brand?', 'Not relatable$Confusing$Somewhat relatable$I can easily relate', '1,2,3,4', 'image_1$image_2$image_3$image_5',5, 'q16', '2018-07-23 05:54:53', '2018-07-23 05:54:53', 0),
(2, 'Can the application be treated as a benchmark?', 'No, cannot see this as a benchmark$Application is okay and as expected$It has got some potential$Yes, can see this as a benchmark', '1,2,3,4', 'image_1$image_2$image_4$image_5', 5, 'q15', '2018-07-04 11:19:13', '2018-07-04 11:19:13', 0),
(3, 'How is the experience of using the application?', 'Worst imaginable$It is stressful$It is ok$Nice experience to use$Best imaginable', '1,2,3,4,5', 'image_1$image_2$image_3$image_4$image_5', 5, 'q14', '2018-07-04 11:18:57', '2018-07-04 11:18:57', 0),
(4, 'How is the application layout, design and colors? ', 'Bad design,</br>needs a serious relook$It is typical as expected and nothing special to appreciate$Nicely designed application$I can see this as a benchmark', '1,2,3,4', 'image_1$image_2$image_4$image_5',  5, 'q13', '2018-07-04 11:18:57', '2018-07-04 11:18:57', 0),
(5, 'Does the application give a sense of accomplishment?', 'Application makes me frustrated but there is no other option$Reluctant to use it again, in need of a substitute$It is alright$Good feeling , will definitely use it again', '1,2,3,4', 'image_1$image_2$image_3$image_5', 4, 'q12', '2018-07-04 11:18:31', '2018-07-04 11:18:31', 0),
(6, 'Is the application customizable?', 'Sad to see no customization$Have it but not required$Too many options for customization$Nicely crafted application to meet my requirements', '1,2,4,5', 'image_1$image_2$image_4$image_5', 4, 'q11', '2018-07-04 11:18:31', '2018-07-04 11:18:31', 0),
(7, 'Is the application difficult to use?', 'I have to try too hard$Some effort is needed$As expected$Intuitive & smooth', '1,2,3,4', 'image_1$image_2$image_3$image_5', 4, 'q10', '2018-07-04 11:18:00', '2018-07-04 11:18:00', 0),
(8, 'Do you think the application is secure?', 'Highly uncertain and non transparent$I am not sure$Maybe$Transparent & secure actions', '1,2,3,4', 'image_1$image_2$image_3$image_5', 3, 'q9', '2018-07-04 11:18:00', '2018-07-04 11:18:00', 0),
(9, 'Did the application encounter a lot of errors during the taskflow?', 'Lot of errors$Some errors$Not many$Task flows are smooth and comforting', '1,2,3,5', 'image_1$image_2$image_4$image_5', 3, 'q8', '2018-07-04 11:17:00', '2018-07-04 11:17:00', 0),
(10, 'Is the application feedback and error messages timely and useful?', 'Not useful$Some are irrelevent$Sufficient enough$Efficient and helps in doing things right ', '1,2,3,4', 'image_1$image_3$image_4$image_5', 3, 'q7', '2018-07-04 11:17:00', '2018-07-04 11:17:00', 0),
(11, 'Is it easy to learn and remember the taskflow?', 'Very hard$Needs some time$Its tricky to start,but easy there after$Intuitive', '1,2,3,4', 'image_1$image_2$image_4$image_5', 2, 'q6', '2018-06-29 13:22:39', '2018-06-30 09:18:35', 0),
(12, 'Can the tasks be performed efficiently and effectively?', 'No$Not really$As expected$To a considerable level$Yes, totally', '0,1,2,3,4', 'image_1$image_2$image_3$image_4$image_5', 2, 'q5', '2018-06-29 11:23:40', '2018-06-29 11:23:40', 0),
(13, 'Is the application easy to navigate and search through?', 'Hard to navigate and search$Some effort is required$As expected$Intutive', '1,2,3,4', 'image_1$image_2$image_3$image_5', 1, 'q4', '2018-06-29 10:52:23', '2018-06-29 10:52:23', 0),
(14, 'Is the help and documentation easy to find and use?', 'Not easy to find,</br>Not useful$Easy to find,</br>Not useful$Not easy to find,</br>But useful$Easy to find And useful', '1,2,3,4', 'image_1$image_2$image_3$image_5', 1, 'q3', '2018-06-29 10:52:23', '2018-06-29 10:52:23', 0),
(15, 'How is the overall systems response time?', 'It takes a long time$Could be faster$Sufficiently fast$Too fast', '1,2,4,5', 'image_1$image_2$image_4$image_5', 1, 'q2', '2018-06-28 12:09:50', '2018-06-28 12:09:50', 0),
(16, 'Is the overall application organized and simple to understand?', 'Needs complete rework$Needs minor improvement$I can do the task efficiently$Optimal', '1,2,3,4', 'image_1$image_2$image_4$image_5', 1, 'q1', '2018-06-28 11:57:31', '2018-06-28 11:57:31', 0);  





CREATE TABLE `feedback` (
  `p_id` int(11) NOT NULL COMMENT 'Product id',
  `user_id` int(11) NOT NULL COMMENT 'User id',
  `p_name` text NOT NULL COMMENT 'Product name',
  `comment` text NOT NULL COMMENT 'feedback comment',
  `helpful` text NOT NULL COMMENT 'helpful'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `responses`
--

CREATE TABLE `responses` (
  `id` int(11) NOT NULL,
  `q_id` varchar(25) DEFAULT NULL COMMENT 'Responses for which category it belongs to',
  `positive` text NOT NULL,
  `negative` text NOT NULL,
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `responses`
--

INSERT INTO `responses` (`id`, `q_id`, `positive`, `negative`, `added_on`, `updated_on`, `is_deleted`) VALUES
(1, 'q1', 'information architecture', 'cluttered information', '2018-07-24 22:08:55', '2018-07-24 22:08:55', 0),
(2, 'q1', 'display of relevant information', 'sorting of relevant information', '2018-07-24 22:08:55', '2018-07-24 22:08:55', 0),
(3, 'q1', 'information organization', 'cluttered information', '2018-07-24 22:12:17', '2018-07-24 22:12:17', 0),
(4, 'q2', 'perceived accuracy', 'feedback from the system', '2018-07-24 22:12:17', '2018-07-24 22:12:17', 0),
(5, 'q2', 'prediction of relevant information', 'processing speed', '2018-07-24 22:13:34', '2018-07-24 22:13:34', 0),
(6, 'q3', 'understandability', 'task assistance', '2018-07-24 22:14:46', '2018-07-24 22:14:46', 0),
(7, 'q3', 'availability of relevant information', 'quality of help provided', '2018-07-24 22:16:16', '2018-07-24 22:16:16', 0),
(8, 'q4', 'information hierarchy ', 'searching for relevant information', '2018-07-24 22:18:23', '2018-07-24 22:18:23', 0),
(9, 'q4', 'easy navigation', 'searching for relevant information', '2018-07-24 22:18:23', '2018-07-24 22:18:23', 0),
(10, 'q5', 'efficiency', 'reachability of reasonable level of usage or proficiency within a short period of time', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(11, 'q5', 'installation', 'ease of upgradation', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(12, 'q6', 'ease in memorising the steps for performing a task', 'effort required to remember and recall while performing a task', '2018-07-24 22:24:01', '2018-07-24 22:24:01', 0),
(13, 'q6', 'minimal actions required to complete tasks', 'number of steps required to complete a task', '2018-07-24 22:24:01', '2018-07-24 22:24:01', 0),
(14, 'q7', 'error prevention', 'appropriate feedback for errors', '2018-07-24 22:08:55', '2018-07-24 22:08:55', 0),
(15, 'q7', 'error rectification', 'appropriate feedback for  errors', '2018-07-24 22:08:55', '2018-07-24 22:08:55', 0),
(16, 'q8', 'visibility of application in current state', 'error visibility', '2018-07-24 22:12:17', '2018-07-24 22:12:17', 0),
(17, 'q8', 'assuring accuracy', 'error visibility', '2018-07-24 22:12:17', '2018-07-24 22:12:17', 0),
(18, 'q9', 'maintaining confidentiality', 'privacy and security', '2018-07-24 22:13:34', '2018-07-24 22:13:34', 0),
(19, 'q9', 'maintaining data integrity', 'privacy and security', '2018-07-24 22:14:46', '2018-07-24 22:14:46', 0),
(20, 'q10', 'minimal mental load while performing tasks', 'reducing conscious effort to work on the system', '2018-07-24 22:16:16', '2018-07-24 22:16:16', 0),
(21, 'q11', 'establishing match between  mental model and conceptual model of the user', 'customization of components', '2018-07-24 22:18:23', '2018-07-24 22:18:23', 0),
(22, 'q12', 'satisfaction of accomplishing any task', 'accessing information', '2018-07-24 22:18:23', '2018-07-24 22:18:23', 0),
(23, 'q13', 'appropriateness of design', 'visual Clutter', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(24, 'q13', 'application color scheme', 'visual Clutter', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(25, 'q14', 'look and feel of the brand', 'appropriateness of the logo used', '2018-07-24 22:24:01', '2018-07-24 22:24:01', 0),
(26, 'q15', 'consistency\r\n', 'spacing and typography used', '2018-07-24 22:24:01', '2018-07-24 22:24:01', 0),
(27, 'q15', 'spacing and typography consistency\r\n', 'header hierarchy', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(28, 'q15', 'animation', 'presentation', '2018-07-24 22:22:44', '2018-07-24 22:22:44', 0),
(29, 'q16', 'satisfaction associated with the product', 'reduction of discomfort and negative attitude towards its use', '2018-07-24 22:24:01', '2018-07-24 22:24:01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL COMMENT 'Siemens email id',
  `fname` varchar(255) DEFAULT NULL COMMENT 'first name',
  `lname` varchar(255) DEFAULT NULL COMMENT 'last name',
  `role` varchar(255) DEFAULT NULL COMMENT 'Relationship with the project',
  `added_on` timestamp NULL DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--



--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `responses`
--
ALTER TABLE `responses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Product Id', AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `responses`
--
ALTER TABLE `responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=305;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
