<?php
$base64 = $_POST['data'];
$finalResult = $_POST['result'];
$userId = $_POST['user_id'];
//$userId = 1;

require_once 'src/config/config.php';
require_once 'src/config/connect.php';
require_once 'src/utils/GeneralMethod.php';
require_once 'src/utils/ConnectionManager.php';
require_once 'library/dompdf/lib/html5lib/Parser.php';
require_once 'library/dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
require_once 'library/dompdf/lib/php-svg-lib/src/autoload.php';
require_once 'library/dompdf/src/Autoloader.php';
Dompdf\Autoloader::register();

use Dompdf\Dompdf;

$genMethod      = new GeneralMethod();
$db             = new ConnectionManager();

$upload_dir = '/var/www/madhu_inst/public_html/siemens/images';
$filename = save_image_file($base64,$upload_dir);
$filename=$filename."";
//print_r('http://localhost/siemens/'.$filename);
//sleep(5);

$sQuery = "SELECT user_id,email,fname FROM users WHERE is_deleted = 0 AND user_id = :user_id";
$db->query($sQuery);
$db->bind(":user_id", $userId);
$rowEmail = $db->single();

if(! empty($rowEmail['email'])) {
    $email = $rowEmail['email'];
//        $rowEmail['email']="varshasbharadwaj@gmail.com";
//                var_dump($email);
//                exit();
//        $crypt_email = $genMethod->simple_crypt($email, 'e');

    $dompdf = new \Dompdf\Dompdf();
    $message = "PFA";
//    print_r($message);
    $src ='https://www.dev-cutech.com/siemens/images/'.$filename.'.svg';
$dompdf->loadHtml("<!DOCTYPE html>
<html>
<head>
    <title>Product Report</title>
                <style type='text/css'>
                    .button,.button span{cursor:pointer;display:inline-block}.button,.button span,.innerbox{display:inline-block}body{background:#ffffff}.pag{background-color:#fff;padding:5px;margin-bottom:20px;-webkit-box-shadow:0 8px 17px 0 rgba(0,0,0,.2),0 6px 20px 0 rgba(0,0,0,.19);box-shadow:0 8px 17px 0 rgba(0,0,0,.2),0 6px 20px 0 rgba(0,0,0,.19);border-radius:5px;border:0}.innerbox{text-align:justify;text-justify:inter-word;padding:20px}.footer{font-size:12px;padding-top:15px}.outerbox{background:#f2f2f2;padding:20px;max-width:700px}a{color:#1372a7}a:hover{color:#007ead}.button{border-radius:4px;background-color:#1372a7;border:none;color:#FFF;text-align:center;font-size:15px;padding:5px;width:165px;transition:all .5s;margin:5px}.button span{position:relative;transition:.5s}.button span:after{content:' bb';position:absolute;opacity:0;top:0;right:-20px;transition:.5s}.button:hover span{padding-right:25px}.button:hover span:after{opacity:1;right:0}
                    .result{height:700px;width:1030px;background-color: #002D31;color: #00ADAF}.page3{height:683px;width: 1030px;}
                    .report{height:683px;width: 1030px;background-color: #009999;}
                   .logo1{position: absolute; right: 0; margin-right: 3%;margin-top: 3%}.down{position: absolute;bottom: 5px;right: 0;}.text-content{position: relative;text-align: right;color: #f7f7f7;padding: 5px} .main-text{font-size: 36px;font-weight: 900;} p{font-size: 18px;	font-weight: 900;}
                    .result-headding{color: #00ADAF;font-size: 36px;font-weight: bold}.tagline{color: #000000;font-size: 18px;}.col-lg-6{width: 525px;margin: 10px;}.rep-content{background-color: #00ADAF}
                    .box{width: 360px; height: 388px;color: #ffffff;margin: 3px;background-color: #009999;border:2px solid #009999; vertical-align: top; right: 0;}
                    .right{
                        position: absolute;right: 0;}
                        li{margin-left: 5px;}
                   /**    .img-holder{display: inline-block;}*/
                </style>
            </head>
<body>
 <div class = 'report'><img class='logo1' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
<div class='down'>
                  <div class='text-content'> 
                       <p class='main-text'>UX MEASUREMENT REPORT FOR <br> ".$finalResult['product_name']." ".$finalResult['version']."  </p>
                        <p>Prepared by CT RDA SSI UXD-IN for ".$rowEmail['fname']." </p>
                  </div>
        </div>
</div>
 <div class=''>
        <img style='float: right' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
        <span class='result-headding'>".$finalResult['product_name']." ".$finalResult['version']." - UX measurement results</span><br>
       <span class='tagline'>The experience calculated is an in-depth evaluation of the product based on five <br>main parameters or components that define the overall experience.</span>
           
                   <div class='img-holder' style='position:relative;'>
                   
                       <img style='float: left;margin-right: 20px; margin-top: 30px;' src=$src height='450px' width='500px'>
                       <span style='clear:left;width:450px;position:absolute;bottom: -60px;'>Above diagram showcases the scores across parameters </span>
                   
                    <div class='box' style='float: right;padding:30px;margin-top: 90px;'>
                        <span style='font-size: 42px;margin: 5px' >" . $finalResult['percentail'] . "%</span><span style='font-size: 18px;display: inline-block;margin: 3px;font-weight: bold'>  UX Score for ".$finalResult['product_name']." ".$finalResult['version']."<br>based on UXMM evaluation</span>
                        <hr style='height: 1px;background: #DAD6D6;margin-top: 20px'>
                        <div class='in-box' style='margin: 5px'>
                               <li><p style='font-weight: 500;margin-left: 10px' >
                               " . $finalResult['positive'] . "</p></li>
                                <li><p style='font-weight: 500;margin-left: 10px'>" . $finalResult['negative'] . "</p></li>
                        </div>
                       
                    </div>
                
             </div>
           </div> 
 </div>
<img src='img/a.jpg' height='700px' width='1031px' ><img src='img/b.jpg' height='700px' width='1031px'>
 <div class = 'report'>
<div class='down'>
                  <div class='text-content'> 
                        <p class='main-text'>THANK YOU</p>
                       
                  </div>
        </div>
</div>

</body>
</html>");

//$options = new Options();

//$options->set('IsRemoteEnabled',true);

//$domPdf->setOptions($options);

// (Optional) Setup the paper size and orientation
$dompdf->setPaper('A4', 'landscape');

    $dompdf->render();
    $time = date('ymdhis');
    $output = $dompdf->output();
    file_put_contents('/var/www/madhu_inst/public_html/siemens/pdf/' . $time . '.pdf', $output);


    $genMethod->sendMails(array($rowEmail['email']), 'Siemens-UXMM Product Report ', $message, $time);
    $aList[JSON_TAG_STATUS] = 0;
}

function save_image_file( $base64, $upload_dir ){
//    $needle = strpos( $base64, ',' );

//    if ( $needle !== false ) {
//        $base64  = substr( $base64, $needle + 1 );
//        $data    = base64_decode( $base64 );
    $uid     = uniqid();
    $file    = $uid;
    $success = file_put_contents( $upload_dir . '/' . $file.'.svg', $base64 );

    return $success ? $uid : false;
//    }

//    return false;
}
?>