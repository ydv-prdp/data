<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/vendor/autoload.php';
//Mpdf\Autoloader::register();
//require_once 'library/mpdf/src/Mpdf.php';
//require_once 'library/mpdf/src/MpdfException.php';
$finalResult['product']='Bempu';
$finalResult['version']='7.23';
$finalResult['name']='Varsha bharadwaj';
$finalResult['positive']="Your product is doing great in terms of Reachability of reasonable level of usage or proficiency within a short period of time, Assuring accuracy, Information architecture.";
$finalResult['negative']="Although your product has reached a considerable level of excellence, yet it can be improved in terms of Satisfaction associated with the product, Improving learning curve of using this product.";
// instantiate and use the dompdf class
//echo $finalResult;

$mpdf = new \Mpdf\Mpdf(['format' => 'A4-L'],'siemens-sans');
$mpdf->SetFont('siemens-sans');
$mpdf->debug =true;
$mpdf->showImageErrors =true;

$mpdf->WriteHTML("<!DOCTYPE html>
<html>
<head>
    <title>Product Report</title>
                <style type='text/css'>
                    @page  {
                    margin: 5%;
                    
                    }
                    body{font-family: 'siemens-sans';}
                    .report{height:683px;width: 1030px;background-color: #009999;}
                   .logo1{position: absolute; right: 0; margin-right: 3%;margin-top: 3%}.down{position: absolute;bottom: 5px;right: 0;}.text-content{position: relative;text-align: right;color: #f7f7f7;padding: 5px} .main-text{font-size: 36px;font-weight: 900;} p{font-size: 18px;	font-weight: 900;}
                    .result-headding{color: #00ADAF;font-size: 26px;font-weight: 900;}.tagline{color: #000000;font-size: 12px;font-weight: 900;padding-left: 10px;font-style:italic}.col-lg-6{width: 525px;margin: 10px;}.rep-content{background-color: #00ADAF}
                    .box{width: 450px; height: 400px;color: #ffffff;margin: 3px;background-color: #009999;border:2px solid #009999; vertical-align: top;}
                    .right{
                        position: absolute;right: 0;}
                       
                    </style>
            </head>
<body>
  <div class = 'report' style='height:100%;width: 100%;background-color: #009999;margin-top: 2%;'><img class='logo1' style='float: right; margin-right: 3%;margin-top: 3%' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
<div class='down' style='margin-top: 90vh;right: 0;'>
                  <div class='text-content' style='margin-right: 3%'> 
                        <p class='main-text' style='margin: 0;margin-top: 500px;padding: 0;font-size: 36px;font-weight: bold;	letter-spacing: 1px;' >UX MEASUREMENT REPORT FOR </p>
                        <p class='main-text' style='padding: 0;margin: 0;font-size: 36px;font-weight: bold;'>".$finalResult['product']." ".$finalResult['version']."  </p>
                        <p style='font-size: 18px;font-weight: 900;padding: 0;'> Prepared by CT RDA SSI UXD-IN for ".$finalResult['name']." </p>
                  </div>
        </div>
</div>
<div>
    <div>
        <img style='float: right' src='img/Report/report-logo.jpg' alt = 'photo' height='55' width='130'>
        <span class='result-headding'>".$finalResult['product']." ".$finalResult['version']." - UX measurement results</span><br>
       <span class='tagline'>The experience calculated is an in-depth evaluation of the product based on five <br>main parameters or components that define the overall experience.</span>
        
    </div>
    <div style='float: left;width:48%;margin-top:60px'>                       
        
        <p style='font-style:italic;font-size:14px;text-align:center'>Above diagram showcases the scores across parameters </p>

    </div>
    <div style='float: right;width:450px;height:400px;background-color:#009999;color: #ffffff;padding:20px;'>
        <div style='float: left;width:20%;margin-left: 15px;'>
            <h1 style='font-size: 42px;font-weight: bold;margin-top:10px;text-align:center'> 66%</h1>
        </div>
        <div style='float: right;width:70%; margin-bottom:0'>  
            <p style='padding:0;margin:0;margin-top:10px'> UX Score for ".$finalResult['product']." ".$finalResult['version']." </p>
            <p style='padding:0;margin:0'> based on UXMM evaluation </p>
        </div>
        <div style='width:100%'> <hr style='height: 2px;color: #ffffff;margin-top:0'>
        </div>
        <ul>
            <li>
            <p style='font-size: 18px;font-style:italic'>" . $finalResult['positive'] . "</p></li>
            <li> <p style='font-size: 18px;font-style:italic'>" . $finalResult['negative'] . "</p></li>
        </ul>
    </div>
</div>    
    
<div style='height:100%;width: 100%;'>
    
</div>  
<div style='height:100%;width: 100%;'>
    <img src='Report/A4 Copy 8.png'>
</div> 
<div class = 'report' style='height:100%;width: 100%;background-color: #009999;margin-top: 2%;'>
<div class='down' style='margin-top: 90vh;right: 0;'>
                  <div class='text-content' style='margin-right: 3%'> 
                        <p class='main-text' style='margin: 0;margin-top: 580px;padding: 0;font-size: 36px;font-weight: bold;	letter-spacing: 1px;' >Thank You </p>
                        
                  </div>
        </div>
</div> 

                



</body>
</html>");

//$mpdf->Output();
$mpdf->Output('img/Report/MyPDF-test.pdf', 'F');
?>