<?php

/*
  Module                      : Index
  File name                   : index.php
  Description                 : All routes are defined here.
 */

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once 'library/vendor/autoload.php';
require_once 'src/config/config.php';
require_once 'src/config/connect.php';
require_once 'src/config/messages.php';
require_once 'src/config/jsontags.php';
require_once 'src/config/errorcodes.php';
require_once 'src/middleware/VerifyAuthKey.php';

require_once 'library/dompdf/lib/html5lib/Parser.php';
require_once 'library/dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
require_once 'library/dompdf/lib/php-svg-lib/src/autoload.php';
require_once 'library/dompdf/src/Autoloader.php';
Dompdf\Autoloader::register();

use Dompdf\Dompdf;

// if development, display errors

if (SERVER == "DEVELOPMENT") {
	$app = new \Slim\App(['settings' => ['displayErrorDetails' => true,'determineRouteBeforeAppMiddleware' => true,
    'displayErrorDetails' => true,
    'addContentLengthHeader' => false,]]);
} else {
	$app = new \Slim\App();
}


//$app->add( new VerifyAuthKey() );


// Users Activity
// To get questions
$app->get('/app/user/questions/{id}', \UsersController::class . ':quest');

//$app->get('/app/user/test', \UsersController::class . ':test');

// To add survey answers
$app->post('/app/user/survey-answer', \UsersController::class . ':answer');

// To add feedback
$app->post('/app/user/feedback', \UsersController::class . ':feedback');

//To store product details
$app->post('/app/user/product-details', \UsersController::class . ':product');

// To get products
$app->get('/app/user/products/{id}', \UsersController::class . ':getProd');

//To store user details
$app->post('/app/user/user-details', \UsersController::class . ':user');

//To add user
$app->post('/app/user/add-user', \UsersController::class . ':addUser');

//To fetch the answer for any answered question
$app->post('/app/user/get-answer', \UsersController::class . ':getAns');

//To fetch the result for any  response
$app->post('/app/user/get-result', \UsersController::class . ':result');

//To store if user is interested
$app->post('/app/user/interest', \UsersController::class . ':interest');

// To get all questions
$app->get('/app/user/get-questions', \UsersController::class . ':allQuestions');

//------------------- Dashboard------------------------------------

//To get graph-details based on response
$app->post('/admin/response-data', \UsersController::class . ':response');

//To get graph-details based on response for pie chart
$app->get('/admin/pie-graph', \UsersController::class . ':pieGraph');

//To get product-details
$app->get('/admin/product-list', \UsersController::class . ':productList');

//To get lead-list
$app->get('/admin/lead-list', \UsersController::class . ':leadList');

//To get user info
$app->get('/admin/get-user/{id}', \UsersController::class . ':getUser');

//To get product-details
$app->post('/admin/product-score', \UsersController::class . ':productScore');

//To get user list of users
$app->get('/admin/product-users/{id}', \UsersController::class . ':productUser');

//To login
$app->post('/admin/login', \UsersController::class . ':adminLogin');





$app->run();
?>
